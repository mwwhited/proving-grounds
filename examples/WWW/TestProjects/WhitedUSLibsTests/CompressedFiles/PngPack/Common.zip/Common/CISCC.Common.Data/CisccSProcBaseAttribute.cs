using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Stored Procedure Identification Attribute.  related to CisccObjectFactory
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public abstract class CisccSProcBaseAttribute: CisccBaseAttribute
    {
        /// <summary>
        /// Constructor for CisccSProcBaseAttribute 
        /// </summary>
        /// <param name="storedProcedureName">Name of stored procedure</param>
        /// <param name="storedProcedureKeys">Key value names for stored procedure</param>
        /// <param name="mySProcType">Stored procedure Type</param>
        public CisccSProcBaseAttribute(string storedProcedureName, string[] storedProcedureKeys, CisccSProcType mySProcType)
        {
            _storedProcedureName = storedProcedureName;
            _storedProcedureKeys = storedProcedureKeys;
            _mySProcType = mySProcType;
        }

        private string _storedProcedureName;
        /// <summary>
        /// Name of Store procedure
        /// </summary>
        public string StoredProcedureName
        {
            get { return _storedProcedureName; }
        }

        private string[] _storedProcedureKeys;
        /// <summary>
        /// Key value names for stored procedure
        /// </summary>
        public string[] StoredProcedureKeys
        {
            get { return _storedProcedureKeys; }
        }

        private CisccSProcType _mySProcType;
        /// <summary>
        /// Stored procedure Type
        /// </summary>
        public CisccSProcType SProcType { get { return _mySProcType; } }
    }
}
