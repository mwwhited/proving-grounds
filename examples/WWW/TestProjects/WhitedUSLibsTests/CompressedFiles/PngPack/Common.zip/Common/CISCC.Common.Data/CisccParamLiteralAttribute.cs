using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

namespace CISCC.Common.Data
{
    /// <summary>
    /// This Attribute works with the CisccObjectFactory to pass class level 
    /// literal parameters to stored procedures
    /// </summary>
    public class CisccParamLiteralAttribute : CisccParamBaseAttribute
    {
        /// <summary>
        /// Constuctor of CisccParamLiteral Attribute for Classes.  It is used 
        /// with CisccObjectFactory to pass literal strings to store procedures 
        /// as parameters
        /// </summary>
        /// <param name="parameterName">Name of Parameter</param>
        /// <param name="value">Value of Parameter</param>
        public CisccParamLiteralAttribute(string parameterName, string value)
            : base(parameterName)
        {
            _value = value;
        }

        private string _value;
        /// <summary>
        /// Value of Parameter to be pased to stored procedures
        /// </summary>
        public string Value { get { return _value; } }

        /// <summary>
        /// method to retrive value related to this attribute
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>SqlParameter</returns>
        public override SqlParameter GetSqlParameter<T>()
        {
            return new SqlParameter(
                this.ParameterName,
                this.Value
            );
        }
    }
}
