using System;
using System.Collections.Generic;
using System.Text;
using CISCC.Common.Security.SecurityAdmin;
using System.Data;

namespace CISCC.Common.Security
{
    /// <summary>
    /// This class is a bridge between the wsSecAdmin and the CISCC.Common.Security
    /// </summary>
    public class SecurityAdapter
    {
        private static SecurityAdapter _instance;

        /// <remarks />
        public static SecurityAdapter Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new SecurityAdapter();
                return _instance;
            }
        }

        /// <remarks />
        public string[] GetUserRoles(string userId)
        {
            DataTable dt = new wsSecAdmin().SelectUserRolesByApp(userId, ApplicationId).Tables[0];
            string[] userRoles = new string[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
                userRoles[i] = dt.Rows[i]["RoleN"] as string;
            return userRoles;
        }

        /// <remarks />
        public string ApplicationName { get { return SecurityConstants.ApplicationName; } }

        private int _applicationId;
        /// <remarks />
        public int ApplicationId
        {
            get
            {
                if (_applicationId == 0)
                {
                    DataRow[] rows = new wsSecAdmin().GetApplications().Tables[0].Select(string.Format("ApplicationN='{0}'", ApplicationName));
                    if (rows.Length < 1)
                        throw new InvalidOperationException(string.Format("Application \"{0}\" is not configured in wsSecAdmin", ApplicationName));
                    else if (rows.Length > 1)
                        throw new InvalidOperationException(string.Format("Application \"{0}\" is miss configured in wsSecAdmin", ApplicationName));
                    else
                        _applicationId = (int)rows[0]["ApplicationI"];
                }
                return _applicationId;
            }
        }

    }
}
