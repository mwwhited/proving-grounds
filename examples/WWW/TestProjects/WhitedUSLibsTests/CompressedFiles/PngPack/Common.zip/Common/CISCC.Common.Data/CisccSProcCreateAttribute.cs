using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Attribute to Identity the Create stored procedure for a class
    /// </summary>
    public class CisccSProcCreateAttribute : CisccSProcBaseAttribute 
    {
        /// <summary>
        /// Constructor for CisccSProcCreateAttribute
        /// </summary>
        /// <param name="storedProcedureName">Name of Stored procedure</param>
        /// <param name="storedProcedureKeys">Key Names for parameters of stored procedure</param>
        public CisccSProcCreateAttribute(string storedProcedureName, string[] storedProcedureKeys)
            : base (storedProcedureName, storedProcedureKeys, CisccSProcType.Create)
        {
        }
    }
}
