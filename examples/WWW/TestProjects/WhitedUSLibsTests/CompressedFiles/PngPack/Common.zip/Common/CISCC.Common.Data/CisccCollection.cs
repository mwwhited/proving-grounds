using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using System.Collections;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Custom Collection for Cissc to assit with caching 
    /// </summary>
    public interface ICisccCollection : ICollection
    {
    }

    /// <summary>
    /// Custom Collection for Cissc to assit with caching 
    /// </summary>
    /// <typeparam name="T">Type to store in collection</typeparam>
    [Serializable]
    public class CisccCollection<T> : Collection<T>, ICisccCollection //where T : ICisccDataObject
    {        
        /// <summary>
        /// Override of ToString Method on Collection
        /// </summary>
        /// <returns>Line per item in collection (up to the first 10)</returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.Min(this.Count, 10); i++)
                sb.AppendFormat("{0}\r\n", this[i]);
            if (this.Count > 10)
                sb.AppendLine("...");
            return sb.ToString();
        }

    }
}
