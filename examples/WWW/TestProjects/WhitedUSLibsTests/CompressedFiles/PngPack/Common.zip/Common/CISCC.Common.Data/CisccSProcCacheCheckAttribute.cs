using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Attribute to Identify the Cache stored procedure for a class
    /// </summary>
    public class CisccSProcCacheCheckAttribute : CisccSProcBaseAttribute
    {
        /// <summary>
        /// Constructor for CisccSProcCacheAttribute
        /// </summary>
        /// <param name="storedProcedureName">Name of Stored procedure</param>
        /// <param name="storedProcedureKeys">Key Names for parameters of stored procedure</param>
        public CisccSProcCacheCheckAttribute(string storedProcedureName, string[] storedProcedureKeys)
            : base (storedProcedureName, storedProcedureKeys, CisccSProcType.CacheCheck)
        {
        }

        private int _expiry;
        /// <remarks />
        public int ExpiryMinutePeriod
        {
            get { return _expiry; }
            set { _expiry = value; }
        }
    }
}
