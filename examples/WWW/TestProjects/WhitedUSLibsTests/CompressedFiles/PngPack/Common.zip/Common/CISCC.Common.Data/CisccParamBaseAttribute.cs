using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Base class attribute to get class assigned parameter values to stored procedures
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, Inherited= false, AllowMultiple=true)]
    public abstract class CisccParamBaseAttribute : CisccBaseAttribute 
    {
        /// <summary>
        /// Base Constructor to pass Parameter name to class
        /// </summary>
        /// <param name="parameterName">Name of Parameter for stored procedure</param>
        public CisccParamBaseAttribute(string parameterName)
        {
            _parameterName = parameterName;
        }

        /// <summary>
        /// Base Constructor to pass Parameter name to class
        /// </summary>
        /// <param name="parameterName">Name of Parameter for stored procedure</param>
        /// <param name="useWith">Type of stored procedures related to this attribute</param>
        public CisccParamBaseAttribute(string parameterName, CisccSProcType useWith)
        {
            _parameterName = parameterName;
            _useWith = useWith;
        }

        private CisccSProcType _useWith = CisccSProcType.CRUD;
        /// <summary>
        /// Type of stored procedures related to this attribute
        /// </summary>
        public CisccSProcType UseWith { 
            get { return _useWith; }
            set { _useWith = value; }
        }

        private string _parameterName;
        /// <summary>
        /// Name of Parameter for stored procedure
        /// </summary>
        public string ParameterName { get { return _parameterName; } }

        /// <summary>
        /// method to retrive value related to this attribute
        /// </summary>
        /// <typeparam name="T">Generic type of ICisccDataObject</typeparam>
        /// <returns>SqlParameter</returns>
        public abstract SqlParameter GetSqlParameter<T>() where T : ICisccDataObject, new();
    }
}
