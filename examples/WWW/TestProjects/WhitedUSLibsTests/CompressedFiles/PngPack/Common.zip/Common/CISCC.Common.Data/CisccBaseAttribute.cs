using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// base Class for all Ciscc Attributes
    /// </summary>
    public abstract class CisccBaseAttribute : Attribute
    {
    }
}
