using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.ComponentModel;
using CISCC.Common.Security;

//CISCC.Common.Web.Controls.CisccXmlSiteMapProvider
namespace CISCC.Common.Web.Controls
{
    /// <summary>
    /// Custom SiteMapProvider to filter based on CISCC Roles
    /// </summary>
    public class CisccXmlSiteMapProvider : XmlSiteMapProvider
    {
        //private RoleTypes _currentRoles;
        private RoleTypes CurrentRoles
        {
            get
            {
                //if (_currentRoles == 0)
                //    _currentRoles = CisccPrincipalUser.CurrentRoles;
                return CisccPrincipalUser.CurrentRoles; //_currentRoles;
            }
        }

        /// <summary>
        /// Child filter is  Security Trimming is Enabled
        /// </summary>
        /// <param name="node">Current SiteMapNode</param>
        /// <returns>SiteMapNodeCollection of Allowed Children</returns>
        public override SiteMapNodeCollection GetChildNodes(SiteMapNode node)
        {
            SiteMapNodeCollection children = new SiteMapNodeCollection();

            if (node.Provider.SecurityTrimmingEnabled)
            {
                foreach (SiteMapNode childNode in base.GetChildNodes(node))
                {
                    RoleTypes roleTypes = SecUtil.RolesToTypes(childNode.Roles);
                    if (SecUtil.MatchedRoles(CurrentRoles, roleTypes))
                        children.Add(childNode);
                }
            }
            else
                children.AddRange(base.GetChildNodes(node));

            return children;
        }
    }
}
