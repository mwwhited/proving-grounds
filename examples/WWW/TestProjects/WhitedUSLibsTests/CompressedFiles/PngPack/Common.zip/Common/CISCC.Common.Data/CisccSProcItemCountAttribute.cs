using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Attribute to Identify the ItemCount stored procedure for a class
    /// </summary>
    public class CisccSProcItemCountAttribute : CisccSProcBaseAttribute
    {
        /// <summary>
        /// Constructor for CisccSProcItemCountAttribute
        /// </summary>
        /// <param name="storedProcedureName">Name of Stored procedure</param>
        /// <param name="storedProcedureKeys">Key Names for parameters of stored procedure</param>
        public CisccSProcItemCountAttribute(string storedProcedureName, string[] storedProcedureKeys)
            : base(storedProcedureName, storedProcedureKeys, CisccSProcType.ItemCount)
        {
        }
    }
}
