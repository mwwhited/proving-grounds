using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Enumeration of Possbile UI binding rules
    /// </summary>
    [Flags]
    public enum CisccUIDisplayBindType
    {
        /// <summary>
        /// You can not test for this value
        /// </summary>
        Default = 0,

        /// <summary>
        /// Bind this property as readonly 
        /// </summary>
        ReadOnly = 1,

        /// <summary>
        /// Bind this property as a hidden value
        /// </summary>
        Hidden = 2,

        /// <summary>
        /// Bind this Property as Locked/Disabled by default
        /// </summary>
        Locked = 4,

        /// <summary>
        /// Do not send this value to the UI at all.  this overrides all over values
        /// </summary>
        DoNotDisplay = 8,

        /// <summary>
        /// Only allowed to edit this field on create or insert
        /// </summary>
        EditOnCreateOnly = 16
    }
}
