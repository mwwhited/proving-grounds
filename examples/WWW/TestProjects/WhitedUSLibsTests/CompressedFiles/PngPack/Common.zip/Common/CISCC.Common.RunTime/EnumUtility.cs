using System;
using System.Collections.Generic;
using System.Text;

//http://jacobcarpenters.blogspot.com/2006/11/enum-tryparse.html
namespace CISCC.Common.RunTime
{
    /// <remarks />
    public static class EnumUtility
    {
        /// <remarks />
        public static bool TryParse<T>(string value, out T result)
           where T : struct // error CS0702: Constraint cannot be special class 'System.Enum'
        {
            return TryParse<T>(value, out result, false);
        }

        /// <remarks />
        public static bool TryParse<T>(string value, out T result, bool ignoreCase)
           where T : struct // error CS0702: Constraint cannot be special class 'System.Enum'
        {
            result = default(T);
            if (!typeof(T).IsEnum)
                return false;
            try
            {
                result = (T)Enum.Parse(typeof(T), value, ignoreCase);
                return true;
            }
            catch { }

            return false;
        }
    }

}
