using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Attribute to Identity the Update stored procedure for a class
    /// </summary>
    public class CisccSProcUpdateAttribute : CisccSProcBaseAttribute
    {
        /// <summary>
        /// Constructor for CisccSProcUpdateAttribute
        /// </summary>
        /// <param name="storedProcedureName">Name of Stored procedure</param>
        /// <param name="storedProcedureKeys">Key Names for parameters of stored procedure</param>
        public CisccSProcUpdateAttribute(string storedProcedureName, string[] storedProcedureKeys)
            : base (storedProcedureName, storedProcedureKeys, CisccSProcType.Update)
        {
        }
    }
}
