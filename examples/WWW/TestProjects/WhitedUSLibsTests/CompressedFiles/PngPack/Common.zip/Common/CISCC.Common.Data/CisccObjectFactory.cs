using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml.Serialization;

namespace CISCC.Common.Data
{
    /// <remarks />
    public class CisccObjectFactory<T> where T : class, ICisccDataObject, new()
    {
        private static bool? _dataObjectIsCacheable;
        private static bool DataObjectIsCacheable
        {
            get
            {
                if (!_dataObjectIsCacheable.HasValue)
                    _dataObjectIsCacheable = (typeof(T).GetInterface(typeof(ICisccCacheable).FullName) != null);

                return _dataObjectIsCacheable.Value;
            }
        }

        /// <remarks />
        public static CisccCollection<T> Read()
        {
            if (DataObjectIsCacheable)
                return CisccObjectCache<T>.GetCache();
            else
                return CisccObjectFactory.Read<T>();
        }

        /// <remarks />
        public static CisccCollection<T> Read(int startRecord, int maxRecords)
        {
            if (DataObjectIsCacheable)
            {
                CisccCollection<T> newData = CisccObjectFactory.Read<T>(startRecord, maxRecords);
                CisccObjectCache<T>.BulkUpdateCache(newData);
                return newData;
            }
            else
            {
                return CisccObjectFactory.Read<T>(startRecord, maxRecords);
            }
        }

        /// <remarks />
        public static CisccCollection<T> Read(object[] parameters)
        {
            if (DataObjectIsCacheable)
            {
                CisccCollection<T> newData = CisccObjectFactory.Read<T>(parameters);
                CisccObjectCache<T>.BulkUpdateCache(newData);
                return newData;
            }
            else
            {
                return CisccObjectFactory.Read<T>(parameters);
            }
        }

        /// <remarks />
        public static T Read(string key)
        {
            if (string.IsNullOrEmpty(key))
                return null;

            if (DataObjectIsCacheable)
                return CisccObjectCache<T>.GetCache(key);
            else
                return CisccObjectFactory.Read<T>(key);
        }

        /// <remarks />
        public static T Read(Guid key)
        {
            if (key == Guid.Empty)
                return null;

            if (DataObjectIsCacheable)
                return CisccObjectCache<T>.GetCache(key);
            else
                return CisccObjectFactory.Read<T>(key);
        }

        /// <remarks />
        public static T Read(Guid? key)
        {
            if (key.HasValue && key != Guid.Empty)
                return Read(key.Value);
            return null;
        }

        /// <remarks />
        public static T Read(T dataObject)
        {
            CisccObjectFactory.Read<T>(ref dataObject);

            if (DataObjectIsCacheable)
                CisccObjectCache<T>.UpdateCache(dataObject);

            return dataObject;
        }

        /// <remarks />
        public static CisccCollection<T> Query(object[] parameters)
        {
            if (DataObjectIsCacheable)
            {
                CisccCollection<T> dataObjects = CisccObjectFactory.Query<T>(parameters);
                CisccObjectCache<T>.BulkUpdateCache(dataObjects);
                return dataObjects;
            }
            else
                return CisccObjectFactory.Query<T>(parameters);
        }

        /// <remarks />
        public static CisccCollection<T> Query(object[] parameters, int startRecord, int maxRecords)
        {
            if (DataObjectIsCacheable)
            {
                CisccCollection<T> dataObjects = CisccObjectFactory.Query<T>(parameters, startRecord, maxRecords);
                CisccObjectCache<T>.BulkUpdateCache(dataObjects);
                return dataObjects;
            }
            else
                return CisccObjectFactory.Query<T>(parameters, startRecord, maxRecords);
        }

        /// <remarks />
        public static T Update(T dataObject)
        {
            CisccObjectFactory.Update<T>(ref dataObject);

            //if (DataObjectIsCacheable)
            //    CisccObjectCache<T>.UpdateCache(dataObject);

            return dataObject;
        }

        /// <remarks />
        public static T Create(T dataObject)
        {
            CisccObjectFactory.Create<T>(ref dataObject);

            if (DataObjectIsCacheable)
                CisccObjectCache<T>.UpdateCache(dataObject);

            return dataObject;
        }

        /// <remarks />
        public static T Delete(T dataObject)
        {
            if (dataObject == null || string.IsNullOrEmpty(dataObject.PrimaryKeyValue))
                return null;

            string key = dataObject.PrimaryKeyValue;

            CisccObjectFactory.Delete<T>(ref dataObject);

            if (DataObjectIsCacheable)
                CisccObjectCache<T>.RemoveCache(key);

            return dataObject;
        }

        /// <remarks />
        public static int ItemCount(object[] parameter)
        {
            return CisccObjectFactory.ItemCount<T>(parameter);
        }
    }
}