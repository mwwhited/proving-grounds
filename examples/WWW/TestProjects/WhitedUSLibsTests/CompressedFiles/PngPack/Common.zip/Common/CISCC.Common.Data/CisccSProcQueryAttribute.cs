using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Attribute to Identify the Query stored procedure for a class
    /// </summary>
    public class CisccSProcQueryAttribute : CisccSProcBaseAttribute
    {
        /// <summary>
        /// Constructor for CisccSProcQueryAttribute
        /// </summary>
        /// <param name="storedProcedureName">Name of Stored procedure</param>
        /// <param name="storedProcedureKeys">Key Names for parameters of stored procedure</param>
        public CisccSProcQueryAttribute(string storedProcedureName, string[] storedProcedureKeys)
            : base (storedProcedureName, storedProcedureKeys, CisccSProcType.Query)
        {
        }
    }
}
