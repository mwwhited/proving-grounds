using System;
using System.Text;

namespace CISCC.Common.Security
{
    /// <summary>
    /// Interface to Identity a Principal via StandardId
    /// </summary>
    public interface IPrincipalUser
    {
        /// <summary>
        /// JPMC StandardID ^[A-Z]{1}[0-9]{6}$
        /// </summary>
        string StandardId
        {
            get;
            set;
        }
    }
}
