using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Principal;
using CISCC.Common.Data;
using System.Diagnostics;
using System.Web;
using System.Threading;
using System.Collections.ObjectModel;
using CISCC.Common.Security.SecurityAdmin;

namespace CISCC.Common.Security
{
    /// <summary>
    /// Profile / Context Principal User 
    /// </summary>
    [Serializable]
    public class CisccPrincipalUser : IPrincipal, IPrincipalUser
    {
        /// <remarks />
        ~CisccPrincipalUser()
        {
            if (this != null)
                this.LogoutUser();
        }

        private string _standardId;
        private IIdentity _identity;
        private string[] _inRoles;
        private JpmcEmployee _employeeData;

        /// <summary>
        /// This function will trim the domain/netbios from windows accounts
        /// </summary>
        /// <param name="currentPrincipalName">existing principal name</param>
        /// <returns>cleaned principal name</returns>
        public static string CleanPrincipalName(string currentPrincipalName)
        {
            if (!string.IsNullOrEmpty(currentPrincipalName))
            {
                currentPrincipalName = currentPrincipalName + " ";
                while (currentPrincipalName.Contains("/"))
                    currentPrincipalName = currentPrincipalName.Substring(currentPrincipalName.IndexOf("/") + 1);
                while (currentPrincipalName.Contains("\\"))
                    currentPrincipalName = currentPrincipalName.Substring(currentPrincipalName.IndexOf("\\") + 1);
                currentPrincipalName = currentPrincipalName.Trim().ToUpper();

                if (PrincipalUser.ValidStandardId.IsMatch(currentPrincipalName))
                    return currentPrincipalName;
            }
            return null;
        }

        /// <summary>
        /// Constructor for Context user
        /// </summary>
        /// <param name="standardId">Standard ID value</param>
        private CisccPrincipalUser(string standardId)
        {
            _standardId = CleanPrincipalName(standardId);

            if (string.IsNullOrEmpty(_standardId))
                throw new InvalidOperationException("Standard ID must not be null and vaild");
        }

        private volatile static Dictionary<string, CisccPrincipalUser> _userDictionary = new Dictionary<string, CisccPrincipalUser>();
        private static object _userDictionaryLock = new object();

        internal static ReadOnlyCollection<CisccPrincipalUser> CurrentPrincipalUsers
        {
            get
            {
                List<CisccPrincipalUser> principalUsers = new List<CisccPrincipalUser>();

                lock (_userDictionaryLock)
                {
                    foreach (CisccPrincipalUser principalUser in _userDictionary.Values)
                        principalUsers.Add(principalUser);
                }

                return principalUsers.AsReadOnly();
            }
        }

        /// <remarks />
        public static ReadOnlyCollection<CisccPrincipalUser> GetCurrentPrincipalUsers() { return CurrentPrincipalUsers; }

        /// <remarks />
        public static ReadOnlyCollection<string> CurrentUserNames
        {
            get
            {
                List<string> principalUsers = new List<string>();

                lock (_userDictionaryLock)
                {
                    foreach (string key in _userDictionary.Keys)
                        principalUsers.Add(key);
                }

                return principalUsers.AsReadOnly();
            }
        }

        /// <remarks />
        public static CisccPrincipalUser GetCisccPrincipalUser(string standardId) 
        {
            if (string.IsNullOrEmpty(standardId))
                return null;

            standardId = standardId.ToUpper();

            lock (_userDictionaryLock)
            {
                if (!_userDictionary.ContainsKey(standardId))
                    _userDictionary.Add(standardId, new CisccPrincipalUser(standardId));

                return _userDictionary[standardId];
            }
        }

        /// <remarks />
        public void LogoutUser()
        {
            LogoutUser(this);
        }

        /// <remarks />
        public static void LogoutUser(CisccPrincipalUser cisccPrincipalUser)
        {
            if (cisccPrincipalUser == null || string.IsNullOrEmpty(cisccPrincipalUser.StandardId))
                return;

            cisccPrincipalUser.FlushRoles();
            string standardId = cisccPrincipalUser.StandardId.ToUpper();

            lock (_userDictionaryLock)
            {
                if (_userDictionary.ContainsKey(standardId))
                    _userDictionary.Remove(standardId);
            }
        }

        /// <remarks />
        public static void LogoutCurrentUser()
        {
            if (CurrentPrincipal != null)
                LogoutUser(CurrentPrincipal);
        }

        #region IPrincipal Members

        /// <summary>
        /// Identity of this Principal
        /// </summary>
        public IIdentity Identity
        {
            get
            {
                if (_identity == null)
                    _identity = new GenericIdentity(_standardId);

                return _identity;
            }
        }

        /// <summary>
        /// Method to check if the current Principal is in a selected role
        /// </summary>
        /// <param name="role">Role to look for</param>
        /// <returns>True if the Principal is in the Role</returns>
        public bool IsInRole(string role)
        {
            if (string.IsNullOrEmpty(role))
                return false;

            foreach (string inRole in Roles)
                if (inRole == role)
                    return true;

            return false;
        }

        #endregion

        /// <summary>
        /// string[] of all Roles that this principal is in
        /// </summary>
        public string[] Roles
        {
            get
            {
                if (_inRoles == null)
                    _inRoles = SecurityAdapter.Instance.GetUserRoles(_standardId);
                return _inRoles;
            }
        }

        /// <remarks />
        public CisccCollection<string> MyRoles
        {
            get
            {
                CisccCollection<string> myRoles = new CisccCollection<string>();
                foreach (string role in Roles)
                    myRoles.Add(role);
                return myRoles;
            }
        }

        /// <summary>
        /// Clear cached role to allow recalculation
        /// </summary>
        public void FlushRoles()
        {
            _inRoles = null;
        }


        /// <summary>
        /// Standard Id of this principal
        /// </summary>
        public string StandardId { get { return _standardId; } }

        /// <summary>
        /// Employee Information that belongs to this Principal
        /// </summary>
        public JpmcEmployee EmployeeData
        {
            get
            {
                if (_employeeData == null)
                    _employeeData = CisccObjectFactory<JpmcEmployee>.Read(this.StandardId);

                return _employeeData;
            }
        }

        #region IPrincipalUser Members

        /// <summary>
        /// The StandardID of a Principal user can not be changed.  But still still allows access for the interface to read this object
        /// </summary>
        string IPrincipalUser.StandardId
        {
            get { return this.StandardId; }
            set { throw new NotImplementedException("Context Principal StandardId can not be changed"); }
        }

        #endregion

        /// <summary>
        /// Method to see if the currently authenticated user is in a particular role
        /// </summary>
        /// <param name="roleName">Role to look for</param>
        /// <returns>True if is in Role</returns>
        public static bool CurrentPrincipalIsInRole(string roleName)
        {
            if (CurrentPrincipal == null || !CurrentPrincipal.IsInRole(roleName))
                return false;
            else
                return true;
        }

        /// <summary>
        /// Currently Active Roles
        /// </summary>
        public static RoleTypes CurrentRoles
        {
            get
            {
                if (CurrentPrincipal == null)
                    return (RoleTypes)0;

                return SecUtil.RolesToTypes(CurrentPrincipal.Roles);
            }
        }

        /// <summary>
        /// Get name from the current principal user or thread
        /// </summary>
        public static string CurrentPrincipalName
        {
            get
            {
                if (CurrentPrincipal != null && CurrentPrincipal.Identity != null)
                    return CurrentPrincipal.Identity.Name;
                else
                    return DataConstants.CurrentPrincipalUser;
            }
        }

        /// <summary>
        /// This will retrive the current contextual principal
        /// </summary>
        public static CisccPrincipalUser CurrentPrincipal
        {
            get
            {
                CisccPrincipalUser _currentPrincipal = null;

                //Try getting User Profile from HTTP Session First
                if ((_currentPrincipal == null || _currentPrincipal.EmployeeData == null) &&
                    (HttpContext.Current != null && 
                    HttpContext.Current.Session != null && 
                    HttpContext.Current.Session[SecurityConstants.UserProfile] != null)
                    )
                    _currentPrincipal = HttpContext.Current.Session[SecurityConstants.UserProfile] as CisccPrincipalUser;

                //If no employe data then clear this valuel
                if (_currentPrincipal != null && _currentPrincipal.EmployeeData == null)
                    _currentPrincipal = null;

                return _currentPrincipal;
            }
        }
    }
}
