using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace CISCC.Common.Web.Controls
{
    /// <summary>
    /// This control attemps to fix a CSS/Style bug in the built 
    /// in ASP.Net calendar control
    /// </summary>
    public class CisccCalendar : Calendar
    {
        /// <remarks />
        protected override void OnDayRender(TableCell cell, CalendarDay day)
        {
            ClearSytles(cell);
            base.OnDayRender(cell, day);
        }

        private void ClearSytles(Control ctrl)
        {
            foreach (Control _ctrl in ctrl.Controls)
                ClearSytles(_ctrl);

            WebControl _webCtrl = ctrl as WebControl;
            if (_webCtrl != null)
            {
                string _cssClassI = _webCtrl.CssClass;
                _webCtrl.ControlStyle.Reset();
                _webCtrl.Style.Clear();
                _webCtrl.CssClass = _cssClassI;
            }
        }
    }
}
