using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using CISCC.Common.Security;
using System.ComponentModel;
using System.Web.UI;
using System.Collections.ObjectModel;
using System.Drawing.Design;
using System.Web.UI.Design;

namespace CISCC.Common.Web.Controls
{
    /// <summary>
    /// This is an overload for the LinkedButton control to prevent 
    /// access based on an asigned set of roles.
    /// </summary>
    /// <remarks>
    /// If the "CisccPrincipaluser.CurrentRoles" user roles are not allowed by 
    /// the "AllowedRoleTypes" property this control will not render 
    /// and will be disabled.
    /// </remarks>
    [ParseChildren(true)]
    [PersistChildren(false)]
    public class CisccLinkButton : LinkButton
    {
        /// <summary>
        /// Flag Enumerages list of Roles that are granted access 
        /// to this control
        /// </summary>
        [DesignOnly(true)]
        public RoleTypes AllowedRoleTypes
        {
            get
            {
                if (ViewState["AllowedRoleTypes"] == null)
                    return (RoleTypes)0;
                else
                    return (RoleTypes)ViewState["AllowedRoleTypes"];
            }
            set
            {
                ViewState["AllowedRoleTypes"] = value;
            }
        }

        /// <summary>
        /// Default method for granting access to this control.
        /// </summary>
        /// <remarks>
        /// This compares the list of "AllowedRoleTypes" to the 
        /// "CisccPrincipaluser.CurrentRoles"
        /// </remarks>
        /// <returns></returns>
        public virtual bool IsAllowed()
        {
            try
            {
                return SecUtil.IsCurrentAllowed(AllowedRoleTypes);
            }
            catch { return false; }
        }

        /// <summary>
        /// This control will not be visible if is not allowed or
        /// is set to not visible
        /// </summary>
        [DefaultValue(false)]
        [Bindable(true)]
        public override bool Visible
        {
            get { return IsAllowed() && base.Visible; }
            set { base.Visible = value; }
        }

        /// <summary>
        /// This control will not be enable if is not allowed or
        /// is set to not visible
        /// </summary>
        [DefaultValue(false)]
        [Bindable(true)]
        public override bool Enabled
        {
            get { return IsAllowed() && base.Enabled; }
            set { base.Enabled = value; }
        }
    }
}
