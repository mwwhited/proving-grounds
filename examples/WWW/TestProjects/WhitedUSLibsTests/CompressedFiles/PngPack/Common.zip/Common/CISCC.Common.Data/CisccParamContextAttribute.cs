using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Reflection;
using CISCC.Common.RunTime;

namespace CISCC.Common.Data
{
    /// <summary>
    /// CISCC Object Factory Stored Procedure Parameter. 
    /// </summary>
    /// <remarks>
    /// The first property must be a static context property.  The last property will 
    /// be used as the value.  If a property is null in the path, the parameter will 
    /// be sent as null.
    /// 
    /// If there are only two parts seperated by semicolons (;) the execusting assebly
    /// will be check for the type.  If only the property path is set. The current 
    /// class will be used.
    /// </remarks>
    public class CisccParamContextAttribute : CisccParamBaseAttribute
    {
        /// <summary>
        /// CISCC Object Factory Stored Procedure Parameter. 
        /// </summary>
        /// <remarks>
        /// The first property must be a static context property.  The last property will 
        /// be used as the value.  If a property is null in the path, the parameter will 
        /// be sent as null.
        /// 
        /// If there are only two parts seperated by semicolons (;) the execusting assebly
        /// will be check for the type.  If only the property path is set. The current 
        /// class will be used.
        /// </remarks>
        /// <param name="parameterName">Variable Parameter name</param>
        /// <param name="appContextObjectType">Type of Context Object</param>
        /// <param name="propertyName">Property from Context Object</param>
        public CisccParamContextAttribute(string parameterName, Type appContextObjectType, string propertyName)
            : base(parameterName)
        {
            _propertyName = propertyName;
            _appContextObjectType = appContextObjectType;
        }

        private string _propertyName;
        /// <summary>
        /// Name of Property on "AppContentPath" to map
        /// </summary>
        public string PropertyName { get { return _propertyName; } }

        private Type _appContextObjectType;
        /// <summary>
        /// Application Context Object Type. 
        /// </summary>
        public Type AppContextPath { get { return _appContextObjectType; } }

        /// <summary>
        /// method to retrive value related to this attribute
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>SqlParameter</returns>
        public override SqlParameter GetSqlParameter<T>()
        {
            if (this.AppContextPath == null)
                throw new CisccAttributeException();

            object _paramValue = null;
            Type _contextObject = this.AppContextPath;


            PropertyInfo _propInfo = _contextObject.GetProperty(this.PropertyName);
            GenericGetter propGetter = DynamicProperty.CreateGetMethod(_propInfo);
            object _propValue = propGetter((object[])null);
            _paramValue = _propValue;


            return new SqlParameter(
                 this.ParameterName,
                 _paramValue
             );

        }
    }
}
