using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// CisccAttributeException is thrown when required attributes are missing
    /// </summary>
    public class CisccAttributeException : NullReferenceException
    {
        /// <summary>
        /// Default Constructor for CisccAttributeException
        /// </summary>
        public CisccAttributeException()
        {
        }

        /// <summary>
        /// Message Constructor for CisccAttributeException
        /// </summary>
        /// <param name="message">Message to throw</param>
        public CisccAttributeException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Message and InnerException Constructor for CisccAttributeException
        /// </summary>
        /// <param name="message">Message to throw</param>
        /// <param name="innerException">Exception that caused this to be thrown</param>
        public CisccAttributeException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Default message property for exception
        /// </summary>
        public override string Message
        {
            get
            {
                if (string.IsNullOrEmpty(base.Message))
                    return "Missing or Invalid CISCC Attribute";
                else
                    return base.Message;
            }
        }
    }
}
