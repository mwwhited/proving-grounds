using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using System.Collections;
using System.Data.SqlClient;
using System.Data;

namespace CISCC.Common.Data
{
    /// <remarks />
    public class CisccObjectCache
    {
        private volatile static List<IDictionary> _allCache = new List<IDictionary>();
        internal static List<IDictionary> AllCache { get { return _allCache; } }

        private volatile static List<CacheStats> _allCacheStats = new List<CacheStats>();
        internal static List<CacheStats> InternalAllCacheStats { get { return _allCacheStats; } }

        /// <remarks />
        public static ReadOnlyCollection<CacheStats> AllCacheStats
        {
            get { return _allCacheStats.AsReadOnly(); }
        }

        /// <remarks />
        public static ReadOnlyCollection<CacheStats> GetAllCacheStats()
        {
            return AllCacheStats;
        }

        /// <remarks />
        public static CacheStats SummaryCacheStats
        {
            get { return CacheStats.Summerize(AllCacheStats); }
        }
    }

    /// <summary>
    /// Class to Cache Business Objects
    /// </summary>
    /// <typeparam name="T">Type of Object to cache</typeparam>
    internal class CisccObjectCache<T> : CisccObjectCache where T : class, ICisccDataObject, new()
    {
        static CisccObjectCache()
        {
            CisccObjectCache.AllCache.Add(_cacheDepot);
            CisccObjectCache.InternalAllCacheStats.Add(_cacheStats);
        }

        private static CacheStats _cacheStats = new CacheStats(typeof(CisccObjectCache<T>));

        private volatile static Dictionary<string, T> _cacheDepot = new Dictionary<string, T>();
        private static object _cacheDepotLock = new object();

        internal static void UpdateCache(T dataObject)
        {
            if (dataObject == null || string.IsNullOrEmpty(dataObject.PrimaryKeyValue))
                return;

            string key = dataObject.PrimaryKeyValue.ToUpper();

            lock (_cacheDepotLock)
            {
                if (_cacheDepot.ContainsKey(key))
                {
                    _cacheStats.CacheHits++;
                    if (dataObject is ICisccCacheable && _cacheDepot[key] is ICisccCacheable)
                    {
                        if (((ICisccCacheable)dataObject).ModifiedDateTime > ((ICisccCacheable)_cacheDepot[key]).ModifiedDateTime)
                        {
                            _cacheStats.CacheUpdates++;
                            _cacheDepot[key] = dataObject;
                        }
                    }
                    else
                    {
                        _cacheStats.CacheUpdates++;
                        _cacheDepot[key] = dataObject;
                    }
                }
                else
                {
                    try
                    {
                        _cacheStats.CacheMisses++;
                        _cacheDepot.Add(key.ToUpper(), dataObject);
                    }
                    catch { }
                }
            }
        }

        internal static void BulkUpdateCache(CisccCollection<T> dataObjects)
        {
            if (dataObjects == null || dataObjects.Count < 1)
                return;

            lock (_cacheDepotLock)
            {
                foreach (T dataObject in dataObjects)
                {
                    string key = dataObject.PrimaryKeyValue.ToUpper();
                    if (_cacheDepot.ContainsKey(key))
                    {
                        _cacheStats.CacheHits++;
                        if (dataObject is ICisccCacheable && _cacheDepot[key] is ICisccCacheable)
                        {
                            if (((ICisccCacheable)dataObject).ModifiedDateTime > ((ICisccCacheable)_cacheDepot[key]).ModifiedDateTime)
                            {
                                _cacheDepot[key] = dataObject;
                                _cacheStats.CacheUpdates++;
                            }
                        }
                        else
                        {
                            _cacheStats.CacheUpdates++;
                            _cacheDepot[key] = dataObject;
                        }
                    }
                    else
                    {
                        try
                        {
                            _cacheStats.CacheMisses++;
                            _cacheStats.CacheUpdates++;
                            _cacheDepot.Add(key.ToUpper(), dataObject);
                        }
                        catch { }
                    }
                }
            }
        }

        internal static void RemoveCache(string key)
        {
            if (string.IsNullOrEmpty(key))
                return;

            key = key.ToUpper();
            lock (_cacheDepotLock)
            {
                if (_cacheDepot.ContainsKey(key))
                {
                    _cacheStats.CacheHits++;
                    _cacheDepot.Remove(key);
                }
            }
        }

        internal static T GetCache(string key)
        {
            if (string.IsNullOrEmpty(key))
                return null;

            key = key.ToUpper();

            lock (_cacheDepotLock)
            {
                return GetCacheNoLock(key);
            }
        }

        internal static T GetCache(Guid key)
        {
            if (key == Guid.Empty)
                return null;

            string localKey = key.ToString().ToUpper();
            lock (_cacheDepotLock)
            {
                return GetCacheNoLock(localKey);
            }
        }

        private static T GetCacheNoLock(string key)
        {
            if (_cacheDepot.ContainsKey(key) && !IsCacheDirty())
            {
                _cacheStats.CacheHits++;
                return _cacheDepot[key];
            }
            else
            {
                T newData = CisccObjectFactory.Read<T>(key);
                if (newData != null)
                {
                    if (_cacheDepot.ContainsKey(key))
                    {
                        _cacheStats.CacheDirty++;
                        _cacheDepot.Remove(key);
                    }
                    else
                        _cacheStats.CacheMisses++;

                    try
                    {
                        _cacheDepot.Add(key, newData);
                    }
                    catch { }
                }
                else
                    _cacheStats.CacheErrors++;
                return newData;
            }
        }

        internal static CisccCollection<T> GetCache()
        {
            CisccCollection<T> cacheData = new CisccCollection<T>();
            if (IsCacheDirty())
            {
                lock (_cacheDepotLock)
                {
                    _cacheStats.CacheDirty += _cacheDepot.Count;
                    _cacheDepot.Clear(); //Might wana be alittle more graceful
                }
            }
            else
            {
                lock (_cacheDepotLock)
                {
                    foreach (T hit in _cacheDepot.Values)
                        cacheData.Add(hit);
                }
            }

            if (cacheData.Count < 1)
            {
                cacheData = CisccObjectFactory.Read<T>();

                if (cacheData != null && cacheData.Count > 0)
                {
                    lock (_cacheDepotLock)
                    {
                        foreach (T newData in cacheData)
                            try
                            {
                                _cacheDepot.Add(newData.PrimaryKeyValue.ToUpper(), newData);
                            }
                            catch { }
                    }
                }

                _cacheStats.CacheMisses += cacheData.Count;
            }
            else
                _cacheStats.CacheHits += cacheData.Count;


            return cacheData;
        }

        internal static void ClearCache()
        {
            lock (_cacheDepotLock)
            {
                _cacheDepot.Clear();
            }
        }

        internal static void ClearCacheCounters()
        {
            _cacheStats.CacheHits = 0;
            _cacheStats.CacheMisses = 0;
            _cacheStats.CacheDirty = 0;
            _cacheStats.CacheUpdates = 0;
            _cacheStats.CacheErrors = 0;
        }

        internal static void ClearCacheAndCounters()
        {
            ClearCache();
            ClearCacheCounters();
        }

        private static bool? _hasCheckCacheAttribute;
        private static TimeSpan? _expiry;
        private static DateTime _nextCheck;

        internal static bool CanCheckCache()
        {
            if (!_hasCheckCacheAttribute.HasValue)
            {
                CisccSProcCacheCheckAttribute attrib = CisccObjectFactory.GetStoredProcedureAttribute<T, CisccSProcCacheCheckAttribute>();
                if (attrib != null)
                {
                    _hasCheckCacheAttribute = true;
                    if (attrib.ExpiryMinutePeriod != 0)
                        _expiry = new TimeSpan(0, attrib.ExpiryMinutePeriod, 0);
                }
                else
                {
                    _hasCheckCacheAttribute = false;
                }
            }
            return _hasCheckCacheAttribute.Value;
        }

        internal static bool IsCacheDirty()
        {
            return IsCacheDirty(null);
        }

        internal static bool IsCacheDirty(object[] procValues)
        {
            if (!CanCheckCache())
                return false;

            if (_expiry.HasValue)
            {
                if (_nextCheck > DateTime.UtcNow)
                    return false;
                _nextCheck = DateTime.UtcNow.Add(_expiry.Value);
            }

            bool result = false;
            using (SqlDataAdapter adapter = CisccObjectFactory.GetStoredProcedureAdapter<T, CisccSProcCacheCheckAttribute>(procValues))
            {
                if (adapter != null)
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        CheckCacheData<T> cacheObject = new CheckCacheData<T>();
                        CisccObjectFactory.RowMerger<CheckCacheData<T>>(dt.Rows[0], ref cacheObject);
                        CheckCacheData<T> current = null;

                        if (cacheObject != null)
                        {
                            lock (_cacheDepotLock)
                            {
                                if (_cacheDepot.Count == cacheObject.ItemCount)
                                {
                                    current = new CheckCacheData<T>();
                                    current.ItemCount = _cacheDepot.Count;

                                    foreach (ICisccCacheable dataObject in _cacheDepot.Values)
                                    {
                                        if (dataObject.ModifiedDateTime > current.LastestModifiedDateTime)
                                            current.LastestModifiedDateTime = dataObject.ModifiedDateTime;
                                    }
                                }
                            }

                            if (current != null)
                            {
                                if (cacheObject.LastestModifiedDateTime <= current.LastestModifiedDateTime)
                                    result = true;
                            }
                        }
                    }
                }
            }

            return !result;
        }
    }
}
