using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Web.Controls
{
    /// <summary>
    /// An interface for reuse access to Ciscc Custom DropDownLists
    /// </summary>
    public interface ICisccDropDownList
    {
        /// <summary>
        /// enable auto post back for this control
        /// </summary>
        bool AutoPostBack { get; set; }

        /// <summary>
        /// Allow attachment of a handler for selected index changed
        /// </summary>
        event EventHandler SelectedIndexChanged;

        /// <summary>
        /// Current SelectedValue
        /// </summary>
        string SelectedValue { get; set; }
    }
}
