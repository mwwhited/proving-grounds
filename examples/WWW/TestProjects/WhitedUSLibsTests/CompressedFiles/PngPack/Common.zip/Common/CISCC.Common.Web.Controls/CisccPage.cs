using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using CISCC.Common.Security;
using System.Diagnostics;
using System.ComponentModel;
using System.Reflection;
using System.Web.UI.WebControls;

namespace CISCC.Common.Web.Controls
{
    /// <summary>
    /// Use this page instead of the ASP.Net page class to enable access control 
    /// using the CISCC.Common.Security classes.
    /// </summary>
    /// <remarks>
    /// Currently you must implement your own access control.  It is recomended to 
    /// create a masterpage and add the accesscontrol methods there.  You can simply call 
    /// this pages "IsAllowed()" method to check access control.
    /// </remarks>
    public abstract class CisccPage : Page
    {
        /// <summary>
        /// Override this in your page code behind to assign general page access
        /// </summary>
        protected abstract RoleTypes AllowedRoleTypes { get;}
        
        /// <summary>
        /// This method compared the flag enumeration of Allowed Roles compared to the 
        /// Current Roles os the Current Principal.
        /// </summary>
        /// <returns>True if access is alllowed</returns>
        public virtual bool IsAllowed()
        {
            return SecUtil.IsCurrentAllowed(AllowedRoleTypes);
        }

        //
        // Just for compatibility reasons just handle the page access control in the master page
        //
        //public virtual bool HasCustomAccessControl { get { return false; } }
        //protected override void EnsureChildControls()
        //{
        //    base.EnsureChildControls();
        //    if (HasCustomAccessControl && !IsAllowed())
        //    {
        //        if (this.Master != null)
        //        {
        //            /*
        //             * If this page is not allowed and it has a master page 
        //             * find the content place holders and clear them out
        //             */
        //            MasterPage masterPage = this.Master;
        //            Type masterPageType = masterPage.GetType();
        //            FieldInfo[] fields = masterPageType.GetFields(
        //                BindingFlags.NonPublic | BindingFlags.FlattenHierarchy |
        //                BindingFlags.Instance
        //                );
        //            IList<string> protectControlNames = new List<string>();
        //            foreach (FieldInfo field in fields)
        //            {
        //                if ((field.FieldType == typeof(ITemplate)))
        //                {
        //                    ITemplate template = field.GetValue(masterPage) as ITemplate;
        //                    if (template == null)
        //                        continue;
        //                    string ctrlName = field.Name;
        //                    if (!string.IsNullOrEmpty(ctrlName) &&
        //                        ctrlName.Contains("_"))
        //                    {
        //                        int pos = ctrlName.LastIndexOf("_");
        //                        int len = ctrlName.Length - pos;
        //                        if (pos > ctrlName.Length || len <= 0)
        //                            ctrlName = null;
        //                        else
        //                            ctrlName = ctrlName.Substring(pos, len);
        //                    }
        //                    if (!string.IsNullOrEmpty(ctrlName))
        //                        protectControlNames.Add(ctrlName);
        //                }
        //            }
        //            foreach (string protectControlName in protectControlNames)
        //            {
        //                ContentPlaceHolder cph = masterPage.FindControl(protectControlName) as ContentPlaceHolder;
        //                if (cph != null)
        //                {
        //                    cph.Controls.Clear();
        //                    cph.Controls.Add(new LiteralControl("Sorry but access to this content is denied"));
        //                }
        //            }
        //        }
        //        else
        //        {
        //            /* if this page is not allowed block the content */
        //            Controls.Clear();
        //            Controls.Add(new LiteralControl("Sorry but access to this page is denied"));
        //        }
        //    }
        //}
    }
}
