using System;
using System.Text;

namespace CISCC.Common.Data
{
    /// <remarks />
    public interface IInquiryObject
    {
        /// <remarks />
        Guid? UniqueId
        {
            get;
            set;
        }
    }
}
