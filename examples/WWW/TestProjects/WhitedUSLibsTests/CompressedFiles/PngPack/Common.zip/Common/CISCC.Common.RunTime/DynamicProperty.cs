using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection.Emit;
using System.Reflection;

//http://jachman.wordpress.com/2006/08/22/2000-faster-using-dynamic-method-calls/

namespace CISCC.Common.RunTime
{
    /// <remarks />
    public delegate void GenericSetter(object target, object value);
    /// <remarks />
    public delegate object GenericGetter(object target);

    /// <remarks />
    public class DynamicProperty
    {
        ///
        /// Creates a dynamic setter for the property
        ///
        public static GenericSetter CreateSetMethod(PropertyInfo propertyInfo)
        {
            if (propertyInfo == null)
                return null;

            /*
            * If there�s no setter return null
            */
            MethodInfo setMethod = propertyInfo.GetSetMethod();
            if (setMethod == null)
                return null;

            /*
            * Create the dynamic method
            */
            Type[] arguments = new Type[2];
            arguments[0] = arguments[1] = typeof(object);

            DynamicMethod setter = new DynamicMethod(
              String.Concat("_Set", propertyInfo.Name, "_"),
              typeof(void),
              arguments,
              propertyInfo.DeclaringType
              );
            ILGenerator generator = setter.GetILGenerator();
            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Castclass, propertyInfo.DeclaringType);
            generator.Emit(OpCodes.Ldarg_1);

            if (propertyInfo.PropertyType.IsClass)
                generator.Emit(OpCodes.Castclass, propertyInfo.PropertyType);
            else
                generator.Emit(OpCodes.Unbox_Any, propertyInfo.PropertyType);

            if (setMethod.IsStatic)
                generator.EmitCall(OpCodes.Call, setMethod, null);
            else
                generator.EmitCall(OpCodes.Callvirt, setMethod, null);

            generator.Emit(OpCodes.Ret);

            /*
            * Create the delegate and return it
            */
            return (GenericSetter)setter.CreateDelegate(typeof(GenericSetter));
        }

        ///
        /// Creates a dynamic getter for the property
        ///
        public static GenericGetter CreateGetMethod(PropertyInfo propertyInfo)
        {
            if (propertyInfo == null)
                return null;

            /*
            * If there�s no getter return null
            */
            MethodInfo getMethod = propertyInfo.GetGetMethod();
            if (getMethod == null)
                return null;

            /*
            * Create the dynamic method
            */
            Type[] arguments = new Type[1];
            arguments[0] = typeof(object);

            DynamicMethod getter = new DynamicMethod(
                String.Concat("_Get", propertyInfo.Name, "_"),
                typeof(object),
                arguments,
                propertyInfo.DeclaringType
                );
            ILGenerator generator = getter.GetILGenerator();
            generator.DeclareLocal(typeof(object));

            if (getMethod.IsStatic)
            {
                generator.EmitCall(OpCodes.Call, getMethod, null);
            }
            else
            {
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Castclass, propertyInfo.DeclaringType);
                generator.EmitCall(OpCodes.Callvirt, getMethod, null);
            }

            if (!propertyInfo.PropertyType.IsClass)
                generator.Emit(OpCodes.Box, propertyInfo.PropertyType);

            generator.Emit(OpCodes.Ret);

            /*
            * Create the delegate and return it
            */
            return (GenericGetter)getter.CreateDelegate(typeof(GenericGetter));
        }
    }
}
