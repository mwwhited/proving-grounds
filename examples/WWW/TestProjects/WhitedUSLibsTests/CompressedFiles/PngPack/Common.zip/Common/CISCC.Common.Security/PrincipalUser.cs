using System;
using System.ComponentModel;
using System.Text;
using CISCC.Common.Data;
using System.Text.RegularExpressions;
using CISCC.Common.Security;
using System.Threading;
using System.Web;

namespace CISCC.Common.Security
{
    /// <summary>
    /// Base class for all Principal Information
    /// </summary>
    public class PrincipalUser : IPrincipalUser
    {
        /// <summary>
        /// Regular expression for valid Standard IDs
        /// </summary>
        public static readonly Regex ValidStandardId = new Regex("^[a-zA-Z]{1}[0-9]{6}$");

        private string _standardId;
        /// <summary>
        /// Standard Id is an employee identification number
        /// </summary>
        [DataObjectField(true)]
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.EditOnCreateOnly)]
        public string StandardId
        {
            get { return _standardId; }
            set
            {
                if (string.IsNullOrEmpty(value))
                    _standardId = null;
                else
                    _standardId = value.ToUpper();
            }
        }

        /// <summary>
        /// Current Standard ID based on allowed authenticaion types.  
        /// </summary>
        /// <remarks>
        /// May be null is not allowed/assigned Principal is found
        /// </remarks>
        public static string CurrentId
        {
            get
            {
                if (CurrentEmployee != null)
                    return CurrentEmployee.StandardId;
                else
                    return null;
            }
        }

        /// <summary>
        /// Current JpmcEmployee Object 
        /// </summary>
        /// <remarks>
        /// May be null is not allowed/assigned Principal is found
        /// </remarks>
        public static JpmcEmployee CurrentEmployee
        {
            get
            {
                if (CisccPrincipalUser.CurrentPrincipal == null)
                    return null;

                return CisccPrincipalUser.CurrentPrincipal.EmployeeData;
            }
        }
    }
}
