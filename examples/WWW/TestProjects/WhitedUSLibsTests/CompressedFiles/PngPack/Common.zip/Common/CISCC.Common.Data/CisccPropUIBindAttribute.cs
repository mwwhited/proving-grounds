using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// UI Binding attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple=false, Inherited=true)]
    public class CisccPropUIBindAttribute : CisccPropBaseAttribute
    {
        private CisccUIDisplayBindType _displayRule = CisccUIDisplayBindType.Default;
        /// <summary>
        /// Type of Binding to perform for a given property
        /// </summary>
        public CisccUIDisplayBindType DisplayRule
        {
            get { return _displayRule; }
            set { _displayRule = value; }
        }
    }
}
