using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

namespace CISCC.Common.Data
{
    /// <summary>
    /// This Attribute works with the CisccObjectFactory to pass class type 
    /// as a parameter to stored procedures
    /// </summary>
    public class CisccParamTypeAttribute : CisccParamBaseAttribute
    {
        /// <summary>
        /// Constuctor of CisccParamLiteral Attribute for Classes.  It is used 
        /// with CisccObjectFactory to pass literal strings to store procedures 
        /// as parameters
        /// </summary>
        /// <param name="parameterName">Name of Parameter</param>
        public CisccParamTypeAttribute(string parameterName)
            : base(parameterName)
        {
        }

        /// <summary>
        /// method to retrive value related to this attribute
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>SqlParameter</returns>
        public override SqlParameter GetSqlParameter<T>()
        {
            return new SqlParameter(
                                this.ParameterName,
                                typeof(T).FullName
                            );
        }
    }
}
