using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Diagnostics;
using System.Text.RegularExpressions;
using CISCC.Common.Data.Configuration;

//CISCC.Common.Data.DataConstants
namespace CISCC.Common.Data
{
    /// <summary>
    /// Global Constant values for use in CISCC
    /// </summary>
    public static class DataConstants
    {
        /// <summary>
        /// Date Validation Pattern 
        /// </summary>
        public static string DateValidationPattern
        {
            get { return DataDateConfig.CurrentConfig.ValidDateRegex; }
        }

        /// <summary>
        /// Email Link Format 
        /// </summary>
        public static string EmailLinkFormat
        {
            get { return DataLinkFormatters.CurrentConfig.Email; }
        }

        /// <summary>
        /// Employee Link Format 
        /// </summary>
        public static string EmployeeLinkFormat
        {
            get { return DataLinkFormatters.CurrentConfig.Employee; }
        }

        /// <summary>
        /// Representative Link Format 
        /// </summary>
        public static string RepresentativeLinkFormat
        {
            get { return DataLinkFormatters.CurrentConfig.Representative; }
        }

        /// <summary>
        /// Compliance Link Format 
        /// </summary>
        public static string ComplianceLinkFormat
        {
            get { return DataLinkFormatters.CurrentConfig.Compliance; }
        }

        /// <summary>
        /// WorkMonth DateTime Format 
        /// </summary>       
        public static string WorkMonthDateTimeFormat
        {
            get { return DataDateConfig.CurrentConfig.WorkMonthFormatter; }
        }

        /// <summary>
        /// WorkMonth DateTime Format as string formatter
        /// </summary>     
        public static string WorkMonthDateTimeStringFormatter
        {
            get { return "{0:" + WorkMonthDateTimeFormat + "}"; }
        }

        /// <summary>
        /// Primary DateTime Format 
        /// </summary>       
        public static string PrimaryDateTimeFormat
        {
            get { return DataDateConfig.CurrentConfig.DateFormatter; }
        }

        /// <summary>
        /// Primary DateTime Format as string formatter
        /// </summary>     
        public static string PrimaryDateTimeStringFormatter
        {
            get { return "{0:" + PrimaryDateTimeFormat + "}"; }
        }

        /// <summary>
        /// Current Application Windows User
        /// </summary>
        public static string CurrentWindowsUser
        {
            get
            {
                return System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            }
        }

        /// <summary>
        /// Current Application Principal User
        /// </summary>
        public static string CurrentPrincipalUser
        {
            get
            {
                string _principal = System.Threading.Thread.CurrentPrincipal.Identity.Name;
                if (string.IsNullOrEmpty(_principal))
                    return null;
                else
                    return _principal;
            }
        }

        /// <summary>
        /// Minimum Time value allowed by Microsoft SQL Server
        /// </summary>
        public static readonly DateTime SqlMinimumDateTime = DateTime.Parse("1/1/1753 12:00:00 AM");
    }
}
