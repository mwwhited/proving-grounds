using System;
using System.ComponentModel;
using System.Text;
using CISCC.Common.Data;

namespace CISCC.Common.Security
{
    /// <summary>
    /// ReadOnly Properties
    /// </summary>
    [CisccSProcRead("usp_Common_Read_JpmcEmployee", new string[] { "StandardId" })]
    [CisccSProcQuery("usp_Common_Read_JpmcEmployee", new string[] { 
        "StandardId",
        "NameFirst",
        "NameLast",
        "NameMiddle",
        "DateHireG",
        "DateHireL",
        "DateTerminationG",
        "DateTerminationL",
        "Email",
        "Title",
        "ManagerId",
        "AgentManagerId",
        "InactiveEmployee"
        })]
    public class JpmcEmployee : PrincipalUser, ICisccCacheable
    {
        /// <remarks />
        public static T GetValue<T>(ref T realObject, Guid? realId) where T : class, IInquiryObject, ICisccDataObject, new()
        {
            //does cached object exist
            if (realObject == null)
            {
                //No Cached Object

                //does key exist
                if (realId.HasValue && realId.Value != Guid.Empty)
                {
                    realObject = CisccObjectFactory<T>.Read(realId);
                    return realObject;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                //Cached Object Exists

                //does key exist
                if (realId.HasValue && realId.Value != Guid.Empty)
                {
                    //does key match 
                    if (realObject.UniqueId == realId.Value)
                    {
                        //return cached object
                        return realObject;
                    }
                    else
                    {
                        //dirty cache get new object
                        realObject = CisccObjectFactory<T>.Read(realId);
                        return realObject;
                    }
                }
                else
                {
                    //clear cache
                    realObject = null;
                    return null;
                }

            }
        }

        /// <remarks />
        public static T GetValue<T>(ref T realObject, string realId) where T : JpmcEmployee, ICisccDataObject, new()
        {
            if ((
                realObject == null && !string.IsNullOrEmpty(realId))
                || (realObject != null && realObject.StandardId != realId)
                || (realObject != null && string.IsNullOrEmpty(realId))
                )
            {
                if (!string.IsNullOrEmpty(realId))
                    realObject = CisccObjectFactory<T>.Read(realId);
                else
                    realObject = null;
            }
            return realObject;
        }

        private string _fullName;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public virtual string FullName
        {
            get { return _fullName; }
            set { _fullName = value; }
        }

        private string _fullNameAndId;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public virtual string FullNameAndId
        {
            get { return _fullNameAndId; }
            set { _fullNameAndId = value; }
        }

        private bool _inactiveEmployee;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public bool InactiveEmployee
        {
            get { return _inactiveEmployee; }
            set { _inactiveEmployee = value; }
        }

        private string _nameFirst;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public string NameFirst
        {
            get { return _nameFirst; }
            set { _nameFirst = value; }
        }


        private string _nameMiddle;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public string NameMiddle
        {
            get { return _nameMiddle; }
            set { _nameMiddle = value; }
        }

        private string _nameLast;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public string NameLast
        {
            get { return _nameLast; }
            set { _nameLast = value; }
        }

        private string _email;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        private DateTime _dateHire;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public DateTime DateHire
        {
            get { return _dateHire; }
            set { _dateHire = value; }
        }

        private DateTime _dateTermination;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public DateTime DateTermination
        {
            get { return _dateTermination; }
            set { _dateTermination = value; }
        }

        private string _Title;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }

        private string _managerId;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public string ManagerId
        {
            get { return _managerId; }
            set { _managerId = value; }
        }

        private JpmcEmployee _manager;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public JpmcEmployee Manager
        {
            get { return GetValue(ref _manager, _managerId); }
        }

        private string _agentManagerId;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public string AgentManagerId
        {
            get { return _agentManagerId; }
            set { _agentManagerId = value; }
        }

        private JpmcEmployee _agentManager;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public JpmcEmployee AgentManager
        {
            get { return GetValue(ref _agentManager, _agentManagerId); }
        }

        private string _agentManagerManagerId;
        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public string AgentManagerManagerId
        {
            get
            {
                if (AgentManagerManager == null)
                    return null;
                else if (string.IsNullOrEmpty(_agentManagerManagerId) ||
                    _agentManagerManagerId != AgentManagerManager.StandardId)
                    _agentManagerManagerId = AgentManagerManager.StandardId;

                return _agentManagerManagerId;
            }
        }

        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.ReadOnly)]
        public JpmcEmployee AgentManagerManager
        {
            get
            {
                if (AgentManager != null)
                    return AgentManager.AgentManager;
                else
                    return null;
            }
        }

        /// <remarks />
        public override string ToString()
        {
            return FullName; //FullNameAndId;
        }

        #region ICisccDataObject Members

        /// <remarks />
        [CisccPropUIBind(DisplayRule = CisccUIDisplayBindType.DoNotDisplay)]
        public string PrimaryKeyValue { get { return StandardId; } }

        #endregion

        #region ICisccCacheable Members


        private DateTime _modifiedDateTime;
        /// <remarks/>
        public DateTime ModifiedDateTime
        {
            get { return _modifiedDateTime; }
            set { _modifiedDateTime = value; }
        }

        private DateTime _createdDateTime;
        /// <remarks/>
        public DateTime CreatedDateTime
        {
            get { return _createdDateTime; }
            set { _createdDateTime = value; }
        }

        #endregion
    }
}
