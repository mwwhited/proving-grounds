using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Attribute to Identity the Read stored procedure for a class
    /// </summary>
    public class CisccSProcReadAttribute : CisccSProcBaseAttribute
    {
        /// <summary>
        /// Constructor for CisccSProcReadAttribute
        /// </summary>
        /// <param name="storedProcedureName">Name of Stored procedure</param>
        /// <param name="storedProcedureKeys">Key Names for parameters of stored procedure</param>
        public CisccSProcReadAttribute(string storedProcedureName, string[] storedProcedureKeys)
            : base (storedProcedureName, storedProcedureKeys, CisccSProcType.Read)
        {
        }
    }
}
