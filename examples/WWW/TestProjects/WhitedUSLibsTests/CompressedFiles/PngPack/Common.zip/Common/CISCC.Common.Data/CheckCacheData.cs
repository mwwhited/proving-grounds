using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    //SELECT COUNT(*) AS ItemCount, MAX(ModifiedDateTime) AS LastestModifiedDateTime

    /// <summary>
    /// Cache Check Object
    /// </summary>
    internal abstract class CheckCacheData : ICisccDataObject
    {
        /// <remarks />
        public abstract int ItemCount { get; set;}

        /// <remarks />
        public abstract DateTime LastestModifiedDateTime { get; set;}

        #region ICisccDataObject Members

        /// <remarks />
        public abstract string PrimaryKeyValue { get; }

        #endregion

    }

    /// <summary>
    /// Cache Check Object
    /// </summary>
    /// <typeparam name="T">ICisccDataObject Type</typeparam>
    internal class CheckCacheData<T> : CheckCacheData where T : ICisccDataObject
    {
        private int _itemCount;

        /// <summary>
        /// Count of total number of objects for "T"
        /// </summary>
        public override int ItemCount
        {
            get { return _itemCount; }
            set { _itemCount = value; }
        }

        private DateTime _lastestModifiedDateTime;

        /// <summary>
        /// Time of last modified Object for "T"
        /// </summary>
        public override DateTime LastestModifiedDateTime
        {
            get { return _lastestModifiedDateTime; }
            set { _lastestModifiedDateTime = value; }
        }

        /// <remarks />
        public override string PrimaryKeyValue
        {
            get
            {
                return string.Format("{0}: {1} / {2}", typeof(T).Name, ItemCount, LastestModifiedDateTime);
            }
        }
    }
}
