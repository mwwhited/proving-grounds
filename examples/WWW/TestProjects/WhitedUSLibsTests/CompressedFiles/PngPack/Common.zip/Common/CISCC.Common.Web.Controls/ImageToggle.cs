using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.Design;
using System.Drawing.Design;
using System.Web.UI.Design.WebControls;
using System.Web;
using System.Security.Permissions;

namespace CISCC.Common.Web.Controls
{
    /// <summary>
    /// The ImageToggle control is a bistate control that can be changed with a click.
    /// </summary>
    [Designer(typeof(PreviewControlDesigner))]
    [DefaultProperty("ShowPrimary")]
    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class ImageToggle : ImageButton
    {
        /// <summary>
        /// Public Constructor to enable toggle support
        /// </summary>
        public ImageToggle()
        {
            this.Click += new ImageClickEventHandler(ImageToggle_Click);
        }

        void ImageToggle_Click(object sender, ImageClickEventArgs e)
        {
            ShowPrimary = !ShowPrimary;
        }

        /// <summary>
        /// Standard ImageUrl to support the ImageToggle Control
        /// </summary>
        [DefaultValue("")]
        [Bindable(true)]
        [Editor(typeof(ImageUrlEditor), typeof(UITypeEditor))]
        [UrlProperty]
        public override string ImageUrl
        {
            get
            {
                if (ShowPrimary)
                    return this.ImageUrlPrimary;
                else
                    return this.ImageUrlSecondary;
            }
            set 
            {
                if (ShowPrimary)
                    this.ImageUrlPrimary = value;
                else
                    this.ImageUrlSecondary = value;
            }
        }
       
        /// <summary>
        /// This property is true when the Primary state is set
        /// </summary>
        [DefaultValue(true)]
        [Bindable(true)]
        public virtual bool ShowPrimary
        {
            get
            {
                if (ViewState["ShowPrimary"] != null)
                    return (bool)ViewState["ShowPrimary"];
                return true;
            }
            set { this.ViewState["ShowPrimary"] = value; }
        }

        /// <summary>
        /// Primary State ImageUrl
        /// </summary>
        [DefaultValue("")]
        [Bindable(true)]
        [Editor(typeof(ImageUrlEditor), typeof(UITypeEditor))]
        [UrlProperty]
        public virtual string ImageUrlPrimary
        {
            get
            {
                if (ViewState["ImageUrlPrimary"] != null)
                    return ViewState["ImageUrlPrimary"].ToString();
                return string.Empty;
            }
            set { this.ViewState["ImageUrlPrimary"] = value; }
        }

        /// <summary>
        /// Secondary State ImageUrl
        /// </summary>
        [DefaultValue("")]
        [Bindable(true)]
        [Editor(typeof(ImageUrlEditor), typeof(UITypeEditor))]
        [UrlProperty]
        public virtual string ImageUrlSecondary
        {
            get
            {
                if (ViewState["ImageUrlSecondary"] != null)
                    return ViewState["ImageUrlSecondary"].ToString();
                return string.Empty;
            }
            set { this.ViewState["ImageUrlSecondary"] = value; }
        }
    }
}
