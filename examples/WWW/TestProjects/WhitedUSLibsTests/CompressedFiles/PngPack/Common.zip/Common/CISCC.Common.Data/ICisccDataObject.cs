using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Interface ICisccDataObject is a tag use for the generics in CisccObjectFactory
    /// </summary>
    public interface ICisccDataObject
    {
        /// <summary>
        /// String Value of the Primary Key
        /// </summary>
        string PrimaryKeyValue { get; }
    }
}
