using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;

namespace CISCC.Common.Web.Controls
{
    /// <summary>
    /// Utilities Class for Web Controls
    /// </summary>
    public static class ControlUtilities
    {
        /// <summary>
        /// Method to find Nested Control
        /// </summary>
        /// <remarks>
        /// this will return null if target is not found
        /// </remarks>
        /// <param name="current">Parent to Search</param>
        /// <param name="target">Name of Child</param>
        /// <returns>Instance of targeted control</returns>
        public static Control FindNestedControl(Control current, string target)
        {
            if (current == null || string.IsNullOrEmpty(target))
                return null;

            Control returnVal = current.FindControl(target);
            if (returnVal != null)
                return returnVal;

            foreach (Control nextControl in current.Controls)
            {
                returnVal = FindNestedControl(nextControl, target);
                if (returnVal != null)
                    return returnVal;
            }

            return null;
        }

        /// <summary>
        /// Method to find Nested Control by ID
        /// </summary>
        /// <remarks>
        /// this will return null if target of type "T" is not found
        /// </remarks>
        /// <typeparam name="T">Type of control to find</typeparam>
        /// <param name="current">Parent to Search</param>
        /// <param name="target">Name of Child</param>
        /// <returns>Instance of targeted control</returns>
        public static T FindNestedControl<T>(Control current, string target) where T : Control
        {
            if (current == null || string.IsNullOrEmpty(target))
                return null;

            T returnVal = current.FindControl(target) as T;
            if (returnVal != null)
                return returnVal;

            foreach (Control nextControl in current.Controls)
            {
                returnVal = FindNestedControl<T>(nextControl, target) as T;
                if (returnVal != null)
                    return returnVal;
            }

            return null;
        }

        /// <summary>
        /// Method to find the first Nested Control of Type "T"
        /// </summary>
        /// <remarks>
        /// this will return null if target of type "T" is not found
        /// </remarks>
        /// <typeparam name="T">Type of control to find</typeparam>
        /// <param name="current">Parent to Search</param>
        /// <returns>Instance of targeted control</returns>
        public static T FindNestedControl<T>(Control current) where T : Control
        {
            if (current == null)
                return null;

            if (current is T)
                return current as T;

            T returnVal;

            foreach (Control nextControl in current.Controls)
            {
                returnVal = FindNestedControl<T>(nextControl) as T;
                if (returnVal != null)
                    return returnVal;
            }

            return null;
        }

        /// <remarks />
        public static string ToStringHTML(object item)
        {
            if (item != null)
                return item.ToString().Replace("\r\n", "<br />");
            else
                return null;
        }
    }
}
