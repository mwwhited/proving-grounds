using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

//CISCC.Common.Data.Configuration.DataConfiguration,CISCC.Common.Data.Configuration
namespace CISCC.Common.Data.Configuration
{
    /// <remarks />
    public class DataConfiguration : ConfigurationSection
    {
        /// <remarks />
        [ConfigurationProperty("defaultStatusId")] //, IsRequired = true)]
        public Guid DefaultStatusId
        {
            get
            {
                return (Guid)this["defaultStatusId"];
            }
        }

        /// <remarks />
        [ConfigurationProperty("closedStatusId")] //, IsRequired = true)]
        public Guid ClosedStatusId
        {
            get
            {
                return (Guid)this["closedStatusId"];
            }
        }

        /// <remarks />
        [ConfigurationProperty("sqlSettings", IsRequired = true)]
        public DataSqlSettings SqlSettings
        {
            get
            {
                return this["sqlSettings"] as DataSqlSettings;
            }
        }

        /// <remarks />
        [ConfigurationProperty("linkFormatters", IsRequired = true)]
        public DataLinkFormatters LinkFormatters
        {
            get
            {
                return this["linkFormatters"] as DataLinkFormatters;
            }
        }

        /// <remarks />
        [ConfigurationProperty("dateConfig", IsRequired = true)]
        public DataDateConfig DateConfig
        {
            get
            {
                return this["dateConfig"] as DataDateConfig;
            }
        }

        private static DataConfiguration _dataConfiguration;
        /// <remarks />
        public static DataConfiguration CurrentConfig
        {
            get
            {
                if (_dataConfiguration == null)
                    _dataConfiguration = ConfigurationManager.GetSection("ciscDataAccess") as DataConfiguration;
                return _dataConfiguration;
            }
        }
    }
}