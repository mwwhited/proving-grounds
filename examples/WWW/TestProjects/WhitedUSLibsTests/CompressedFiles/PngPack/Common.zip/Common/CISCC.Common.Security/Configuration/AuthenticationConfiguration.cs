using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CISCC.Common.Security.Configuration
{
    /// <remarks />
    public class AuthenticationConfiguration : ConfigurationElement
    {
        /// <remarks />
        [ConfigurationProperty("ssoHeader", DefaultValue = "STANDARDID")]
        public string SsoHeader
        {
            get { return this["ssoHeader"] as string; }
        }

#if DEBUG

        /// <remarks />
        [ConfigurationProperty("ssoHeaderTestId")]
        public string SsoHeaderTestId
        {
            get { return this["ssoHeaderTestId"] as string; }
        }

#endif

        /// <remarks />
        [ConfigurationProperty("logoutUrl", DefaultValue = "~/")]
        public string LogoutUrl
        {
            get { return this["logoutUrl"] as string; }
        }

        /// <remarks />
        [ConfigurationProperty("userProfile", DefaultValue = "UserProfile")]
        public string UserProfile
        {
            get { return this["userProfile"] as string; }
        }

        /// <remarks />
        public static AuthenticationConfiguration CurrentConfig
        {
            get { return SecurityConfiguration.CurrentConfig.AuthenticationConfig; }
        }
    }
}