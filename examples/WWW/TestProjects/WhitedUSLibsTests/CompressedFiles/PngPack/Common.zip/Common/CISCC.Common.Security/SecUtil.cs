using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace CISCC.Common.Security
{
    /// <summary>
    /// Security Utilities
    /// </summary>
    public static class SecUtil
    {
        /// <summary>
        /// Convert string[] of Roles to the Flag Enumeration of RoleTypes
        /// </summary>
        /// <param name="roles">string[] of RoleNames</param>
        /// <returns>Flag Enumeration Value</returns>
        public static RoleTypes RolesToTypes(IEnumerable roles)
        {
            if (roles == null)
                return (RoleTypes)0;

            RoleTypes currentRoles = (RoleTypes)0;
            foreach (object role in roles)
            {
                if (role == null)
                    continue;

                string selectedRole = role.ToString();
                if (selectedRole == SecurityConstants.RoleMaintenance)
                    currentRoles |= RoleTypes.Maintenance;
                else if (selectedRole == SecurityConstants.RoleReadOnly)
                    currentRoles |= RoleTypes.ReadOnly;
                else if (selectedRole == SecurityConstants.RoleReadWrite)
                    currentRoles |= RoleTypes.ReadWrite;
                else if (selectedRole == SecurityConstants.RolePublisher)
                    currentRoles |= RoleTypes.Publisher;
                else if (selectedRole == SecurityConstants.RoleAllUsers)
                    currentRoles |= RoleTypes.FullAccess;
            }
            return currentRoles;
        }

        /// <summary>
        /// Current Principal is Allowed use of at least one role in "allowedRoles"
        /// </summary>
        /// <param name="allowedRoles">Flag Enumeration of Allowed Roles</param>
        /// <returns>True is access is granted</returns>
        public static bool IsCurrentAllowed(RoleTypes allowedRoles)
        {
            return MatchedRoles(CisccPrincipalUser.CurrentRoles, allowedRoles);
        }

        /// <summary>
        /// Compare two sets of roles.  If at least one role matches then return true;
        /// </summary>
        /// <param name="leftSide">Role set 1</param>
        /// <param name="rightSide">Role set 2</param>
        /// <returns>True if at least one role matches</returns>
        public static bool MatchedRoles(RoleTypes leftSide, RoleTypes rightSide)
        {
            return (leftSide & rightSide) != 0;
        }
    }
}
