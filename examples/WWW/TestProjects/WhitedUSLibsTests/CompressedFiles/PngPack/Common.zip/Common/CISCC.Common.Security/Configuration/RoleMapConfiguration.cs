using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CISCC.Common.Security.Configuration
{
    /// <remarks />
    public class RoleMapConfiguration : ConfigurationElement
    {
        /// <remarks />
        [ConfigurationProperty("readOnly", DefaultValue = "Reader")]
        public string ReadOnly
        {
            get { return this["readOnly"] as string; }
        }

        /// <remarks />
        [ConfigurationProperty("maintenance", DefaultValue = "Application Maintenance")]
        public string Maintenance
        {
            get { return this["maintenance"] as string; }
        }

        /// <remarks />
        [ConfigurationProperty("readWrite", DefaultValue = "Data Entry")]
        public string ReadWrite
        {
            get { return this["readWrite"] as string; }
        }

        /// <remarks />
        [ConfigurationProperty("publisher", DefaultValue = "Publisher")]
        public string Publisher
        {
            get { return this["publisher"] as string; }
        }

        /// <remarks />
        [ConfigurationProperty("allUsers", DefaultValue = "*")]
        public string AllUsers
        {
            get { return this["allUsers"] as string; }
        }

        /// <remarks />
        public static RoleMapConfiguration CurrentConfig
        {
            get { return SecurityConfiguration.CurrentConfig.RoleMap; }
        }
    }
}
