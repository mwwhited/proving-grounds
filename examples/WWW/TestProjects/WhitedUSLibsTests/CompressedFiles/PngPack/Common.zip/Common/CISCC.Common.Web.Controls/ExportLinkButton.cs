using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Web.UI.HtmlControls;
using CISCC.Common.RunTime;
using System.Reflection;

namespace CISCC.Common.Web.Controls
{
    /// <summary>
    /// This control can target a GridView for Export
    /// </summary>
    public sealed class ExportLinkButton : CisccLinkButton 
    {
        /// <summary>
        /// ID for GridView to Target
        /// </summary>
        [DefaultValue((string)null)]
        [Bindable(true)]
        public string TargetGridView
        {
            get { return ViewState["TargetGridView"] as string; }
            set { ViewState["TargetGridView"] = value; }
        }

        /// <summary>
        /// Text to display on button
        /// </summary>
        [DefaultValue("Export")]
        [Bindable(true)]
        public override string Text
        {
            get
            {
                if (string.IsNullOrEmpty(base.Text))
                    return "Export";
                return base.Text;
            }
            set { base.Text = value; }
        }

        /// <summary>
        /// Visible bound to this control and target
        /// </summary>
        [DefaultValue(true)]
        [Bindable(true)]
        public override bool Visible
        {
            get
            {
                if (!string.IsNullOrEmpty(TargetGridView))
                {
                    Control target = ControlUtilities.FindNestedControl(this.Page, TargetGridView);
                    if (target != null)
                        return target.Visible;
                }

                return base.Visible;
            }
            set
            {
                base.Visible = value;
            }
        }

        /// <remarks />
        protected override void OnClick(EventArgs e)
        {
            if (string.IsNullOrEmpty(TargetGridView))
                throw new ArgumentNullException("TargetGridView");

            GridView gridview = ControlUtilities.FindNestedControl<GridView>(this.Page, TargetGridView);

            if (gridview == null)
                throw new NullReferenceException(string.Format("GridView with ID \"{0}\" can not be found", TargetGridView));

            ExportGridView(gridview);
        }

        private void ExportGridView(GridView gridView)
        {
            //export to excel
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
            HttpContext.Current.Response.Charset = "";

            this.EnableViewState = false;
            StringWriter oStringWriter = new StringWriter();
            HtmlTextWriter oHtmlTextWriter = new HtmlTextWriter(oStringWriter);

            gridView.AllowPaging = false;
            gridView.AllowSorting = false;
            gridView.DataBind();
            this.ClearControls(gridView);

            HtmlForm frm = new HtmlForm();
            gridView.Parent.Controls.Add(frm);
            frm.Attributes["runat"] = "server";
            frm.Controls.Add(gridView);
            
            frm.RenderControl(oHtmlTextWriter);
            
            HttpContext.Current.Response.Write(oStringWriter.ToString());
            HttpContext.Current.Response.End();
        }

        private string[] CheckProperties = new string[] {
            "SelectedItem",
            "Checked",
            "Text"
        };

        private volatile static Dictionary<Type, GenericGetter> _cachedGetters = new Dictionary<Type, GenericGetter>();
        private static object _cachedGettersLock = new object();

        private void ClearControls(Control control)
        {
            for (int i = 0; i < control.Controls.Count; i++)
                ClearControls(control.Controls[i]);

            if (!(control is TableCell))
            {
                Type controlType = control.GetType();
                if (controlType == typeof(GridViewRow) ||
                    controlType == typeof(GridView)) 
                    return;

                GenericGetter propGetter = null;

                if (_cachedGetters.ContainsKey(controlType))
                {
                    lock (_cachedGettersLock)
                    {
                        propGetter = _cachedGetters[controlType];
                    }
                }
                else
                {
                    PropertyInfo propInfo = null;
                    bool brokeOut = false;
                    foreach (string checkProperty in CheckProperties)
                    {
                        propInfo = controlType.GetProperty(checkProperty);
                        if (propInfo != null)
                        {
                            propGetter = DynamicProperty.CreateGetMethod(propInfo);
                            if (propGetter != null)
                            {
                                brokeOut = true;
                                lock (_cachedGettersLock)
                                {
                                    if (!_cachedGetters.ContainsKey(controlType))
                                        _cachedGetters.Add(controlType, propGetter);
                                }
                                break;
                            }
                        }
                    }
                    if (!brokeOut)
                    {
                        if (!_cachedGetters.ContainsKey(controlType))
                            _cachedGetters.Add(controlType, null);
                    }
                }

                if (propGetter != null)
                {
                    LiteralControl literal = new LiteralControl();
                    control.Parent.Controls.Add(literal);

                    object resultVal = propGetter(control);

                    if (resultVal is bool)                        
                        literal.Text = ((bool)resultVal) ? "true" : "false";
                    else if (resultVal is string && resultVal != null)
                        literal.Text = (string)resultVal;
                    else if (resultVal != null)
                        literal.Text = resultVal.ToString();

                   control.Parent.Controls.Remove(control);
                }
            }
        }
    }
}
