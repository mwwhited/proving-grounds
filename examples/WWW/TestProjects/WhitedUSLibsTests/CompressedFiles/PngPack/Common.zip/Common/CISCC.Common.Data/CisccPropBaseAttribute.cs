using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// base of Ciscc attributes used with CisccObjectFactory that are related to properties
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public abstract class CisccPropBaseAttribute : CisccBaseAttribute
    {
    }
}
