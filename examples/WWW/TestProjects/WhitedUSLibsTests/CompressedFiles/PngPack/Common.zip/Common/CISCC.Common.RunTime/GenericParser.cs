using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection.Emit;
using System.Reflection;

namespace CISCC.Common.RunTime
{
    /// <remarks />
    public class GenericParser
    {
        private volatile static Dictionary<Type, Delegate> _cachedGenericHandlers = new Dictionary<Type, Delegate>();
        private delegate bool TryParseHandler<T>(string input, out T result);
        private static TryParseHandler<T> GetTryParseHandler<T>()
        {
            if (_cachedGenericHandlers.ContainsKey(typeof(T)))
                return _cachedGenericHandlers[typeof(T)] as TryParseHandler<T>;

            Type[] args = new Type[] { typeof(string), typeof(T).MakeByRefType() };

            MethodInfo mi = typeof(T).GetMethod("TryParse", args);
            if (mi == null)
                return null;

            DynamicMethod dm = new DynamicMethod(
                string.Format("_{0}_TryParse", typeof(T).Name),
                typeof(bool),
                args,
                typeof(T)
            );

            ILGenerator il = dm.GetILGenerator();
            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Ldarg_1);
            il.EmitCall(OpCodes.Call, mi, null);
            il.Emit(OpCodes.Ret);

            TryParseHandler<T> handler = dm.CreateDelegate(typeof(TryParseHandler<T>)) as TryParseHandler<T>;

            _cachedGenericHandlers.Add(typeof(T), handler);

            return handler;
        }

        /// <remarks />
        public static bool TryParse<T>(string input, out T result)
        {
            TryParseHandler<T> handler = GetTryParseHandler<T>();
            if (handler != null)
                return handler(input, out result);
            else
            {
                result = default(T);
                return false;
            }
        }

        private volatile static Dictionary<Type, Delegate> _cachedHandlers = new Dictionary<Type, Delegate>();
        private delegate bool TryParseHandler(string input, out object result);
        private static TryParseHandler GetTryParseHandler(Type T)
        {
            if (_cachedHandlers.ContainsKey(T))
                return _cachedHandlers[T] as TryParseHandler;

            Type[] args = new Type[] { typeof(string), typeof(object).MakeByRefType() };

            MethodInfo mi = T.GetMethod("TryParse", args);
            if (mi == null)
                return null;

            DynamicMethod dm = new DynamicMethod(
                string.Format("_{0}_TryParse", T.Name),
                typeof(bool),
                args,
                T
            );

            ILGenerator il = dm.GetILGenerator();
            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Ldarg_1);
            il.EmitCall(OpCodes.Call, mi, null);
            il.Emit(OpCodes.Ret);

            TryParseHandler handler = dm.CreateDelegate(typeof(TryParseHandler)) as TryParseHandler;

            _cachedGenericHandlers.Add(T, handler);

            return handler;
        }

        /// <remarks />
        public static bool TryParse(Type T, string input, out object result)
        {
            TryParseHandler handler = GetTryParseHandler(T);
            if (handler != null)
                return handler(input, out result);
            else
            {
                result = CreateInstance(T);
                return false;
            }
        }

        private delegate object CreateInstanceHandler();
        /// <remarks />
        public static object CreateInstance(Type T)
        {
            if (T == null)
                throw new NullReferenceException("You must provide a type");

            DynamicMethod dm = new DynamicMethod(
                string.Format("_{0}_CreateInstance", T.Name),
                typeof(object),
                Type.EmptyTypes,
                T
                );
            ILGenerator il = dm.GetILGenerator();
            il.DeclareLocal(typeof(object));
            LocalBuilder lb2 = il.DeclareLocal(T);

            il.Emit(OpCodes.Ldloca_S, lb2);
            il.Emit(OpCodes.Initobj, T);
            il.Emit(OpCodes.Ldloc_1);
            il.Emit(OpCodes.Box, T);
            il.Emit(OpCodes.Ret);

            CreateInstanceHandler handler = dm.CreateDelegate(typeof(CreateInstanceHandler)) as CreateInstanceHandler;
            if (handler == null)
                return null;
            else
                return handler();
        }

        private delegate T CreateInstanceHandler<T>();
        /// <remarks />
        public static T CreateInstance<T>()
        {
            DynamicMethod dm = new DynamicMethod(
                string.Format("_{0}_CreateInstance", typeof(T).Name),
                typeof(T),
                Type.EmptyTypes,
                typeof(T)
                );
            ILGenerator il = dm.GetILGenerator();

            LocalBuilder lb1 = il.DeclareLocal(typeof(T));

            il.Emit(OpCodes.Ldloca_S, lb1);
            il.Emit(OpCodes.Initobj, typeof(T));
            il.Emit(OpCodes.Ldloc_0);
            il.Emit(OpCodes.Ret);

            CreateInstanceHandler<T> handler = dm.CreateDelegate(typeof(CreateInstanceHandler<T>)) as CreateInstanceHandler<T>;
            if (handler == null)
                return default(T);
            else
                return handler();
        }
    }
}
