using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml.Serialization;
using CISCC.Common.RunTime;
using CISCC.Common.Data.Configuration;

namespace CISCC.Common.Data
{

    /// <summary>
    /// Ciscc Inquiry Data Abstraction Layer
    /// </summary>
    internal class CisccObjectFactory
    {
        /// <summary>
        /// Update Method for ICisccDataObject objects
        /// </summary>
        /// <typeparam name="T">ICisccDataObject object type to be updated</typeparam>
        /// <param name="updateObj">ICisccDataObject object to be updated</param>
        public static void Update<T>(ref T updateObj)
            where T : ICisccDataObject, new()
        {
            RunStoredProcedure<T, CisccSProcUpdateAttribute>(ref updateObj);
        }

        /// <summary>
        /// Create Method for ICisccDataObject objects
        /// </summary>
        /// <typeparam name="T">ICisccDataObject object type to be created</typeparam>
        /// <param name="createObj">ICisccDataObject object to be created</param>
        public static void Create<T>(ref T createObj)
            where T : ICisccDataObject, new()
        {
            RunStoredProcedure<T, CisccSProcCreateAttribute>(ref createObj);
        }

        /// <summary>
        /// Read Method for ICisccDataObject objects
        /// </summary>
        /// <typeparam name="T">ICisccDataObject object type to be read</typeparam>
        /// <param name="readObject">ICisccDataObject object to be read</param>
        public static void Read<T>(ref T readObject)
            where T : ICisccDataObject, new()
        {
            RunStoredProcedure<T, CisccSProcReadAttribute>(ref readObject);
        }

        /// <summary>
        /// Delete Method for ICisccDataObject objects
        /// </summary>
        /// <typeparam name="T">ICisccDataObject object type to be deleted</typeparam>
        /// <param name="deleteObject">ICisccDataObject object to be deleted</param>
        public static void Delete<T>(ref T deleteObject)
            where T : ICisccDataObject, new()
        {
            RunStoredProcedure<T, CisccSProcDeleteAttribute>(ref deleteObject);
        }

        #region Read

        /// <remarks />
        public static CisccCollection<T> Read<T>()
            where T : ICisccDataObject, new()
        {
            return RunStoredProcedure<T, CisccSProcReadAttribute>(null);
        }

        /// <remarks />
        public static CisccCollection<T> Read<T>(int startRecord, int maxRecords)
            where T : ICisccDataObject, new()
        {
            return RunStoredProcedure<T, CisccSProcReadAttribute>(null, startRecord, maxRecords);
        }

        /// <remarks />
        public static CisccCollection<T> Read<T>(object[] procValues)
            where T : ICisccDataObject, new()
        {
            return RunStoredProcedure<T, CisccSProcReadAttribute>(procValues, null, null);
        }

        /// <remarks />
        public static int ItemCount<T>(object[] parameter) 
            where T : ICisccDataObject, new()
        {
            object returnValue;
            using (SqlDataAdapter dataAdapter = GetStoredProcedureAdapter<T, CisccSProcItemCountAttribute>(parameter))
            {
                if (dataAdapter.SelectCommand.Connection.State == ConnectionState.Closed)
                    dataAdapter.SelectCommand.Connection.Open();

                returnValue = dataAdapter.SelectCommand.ExecuteScalar();

                if (dataAdapter.SelectCommand.Connection.State != ConnectionState.Closed)
                    dataAdapter.SelectCommand.Connection.Close();
            }

            if (returnValue is int)
                return (int)returnValue;

            throw new InvalidOperationException(string.Format(
                "Invalid return type for ItemCount on Type \"{0}\"",
                typeof(T)
                ));
        }

        /// <remarks />
        public static CisccCollection<T> Query<T>(object[] procValues)
            where T : ICisccDataObject, new()
        {
            return RunStoredProcedure<T, CisccSProcQueryAttribute>(procValues, null, null);
        }

        /// <remarks />
        public static CisccCollection<T> Query<T>(object[] procValues, int startRecord, int maxRecords)
            where T : ICisccDataObject, new()
        {
            return RunStoredProcedure<T, CisccSProcQueryAttribute>(procValues, startRecord, maxRecords);
        }

        /// <remarks />
        public static CisccCollection<T> Read<T>(object[] procValues, int startRecord, int maxRecords)
            where T : ICisccDataObject, new()
        {
            return RunStoredProcedure<T, CisccSProcReadAttribute>(procValues, startRecord, maxRecords);
        }

        /// <remarks />
        public static T ReadSingle<T>(object[] procValues)
            where T : ICisccDataObject, new()
        {
            CisccCollection<T> _allRows = RunStoredProcedure<T, CisccSProcReadAttribute>(procValues, 0, 1);
            if (_allRows != null && _allRows.Count > 0)
                return _allRows[0];
            else
                return default(T);
        }

        /// <remarks />
        public static T Read<T>(string primaryKey)
            where T : ICisccDataObject, new()
        {
            if (string.IsNullOrEmpty(primaryKey))
                return default(T);

            return ReadSingle<T>(new object[] { primaryKey });
        }

        /// <remarks />
        public static T Read<T>(Guid primaryKey)
            where T : ICisccDataObject, new()
        {
            if (primaryKey == null || primaryKey == Guid.Empty)
                return default(T);

            return ReadSingle<T>(new object[] { primaryKey });
        }

        /// <remarks />
        public static T Read<T>(Guid? primaryKey)
            where T : ICisccDataObject, new()
        {
            if (primaryKey == null || primaryKey == Guid.Empty)
                return default(T);

            return ReadSingle<T>(new object[] { primaryKey.Value });
        }

        #endregion

        #region Runners

        /// <summary>
        /// Generic Stored procedure runner that support paging
        /// </summary>
        /// <typeparam name="T">Type of ICisccDataObject to return</typeparam>
        /// <typeparam name="Sp">Type of CisccSProcBaseAttribute Stored procedureto select</typeparam>
        /// <param name="procValues">Input Parameters for CisccSProcBaseAttribute.StoredProcedureKeys</param>
        /// <param name="startRecord">Record to Start at</param>
        /// <param name="maxRecords">Number of Records to retrive</param>
        /// <returns>Collection of typed objects from the stored procedure</returns>
        public static CisccCollection<T> RunStoredProcedure<T, Sp>(object[] procValues, int? startRecord, int? maxRecords)
            where T : ICisccDataObject, new()
            where Sp : CisccSProcBaseAttribute
        {
            Sp _attrib = GetStoredProcedureAttribute<T, Sp>();
            if (procValues != null && _attrib.StoredProcedureKeys.Length != procValues.Length)
                throw new ArgumentOutOfRangeException("Parameter Key/Value missmatch");

            if (_attrib != null)
            {
                DataSet _ds = null;

                if (startRecord == null || maxRecords == null ||
                    startRecord.Value < 0 || maxRecords.Value <= 0)
                    _ds = RunStoredProcedure<T>(_attrib, procValues);
                else
                    _ds = RunStoredProcedure<T>(_attrib, procValues, startRecord.Value, maxRecords.Value);

                if (_ds != null && _ds.Tables.Count == 0)
                    return null;

                DataTable _dt = _ds.Tables[0];
                CisccCollection<T> _outVar = new CisccCollection<T>();
                foreach (DataRow _dr in _dt.Rows)
                {
                    T _obj = RowDeserializer<T>(_dr);
                    if (_obj != null)
                    {
                        _outVar.Add(_obj);
                    }
                }
                return _outVar;
            }
            else
                throw new CisccAttributeException(string.Format(
                    "This \"{0}\" is not configured for \"{1}\"",
                    typeof(T), typeof(Sp)
                    ));
        }

        /// <summary>
        /// Generic Stored procedure runner that returns all records
        /// </summary>
        /// <typeparam name="T">Type of ICisccDataObject to return</typeparam>
        /// <typeparam name="Sp">Type of CisccSProcBaseAttribute Stored procedureto select</typeparam>
        /// <param name="procValues">Input Parameters for CisccSProcBaseAttribute.StoredProcedureKeys</param>
        /// <returns>Collection of typed objects from the stored procedure</returns>
        public static CisccCollection<T> RunStoredProcedure<T, Sp>(object[] procValues)
            where T : ICisccDataObject, new()
            where Sp : CisccSProcBaseAttribute
        {
            return RunStoredProcedure<T, Sp>(procValues, null, null);
        }

        /// <remarks />
        public static DataSet RunStoredProcedure<T>(CisccSProcBaseAttribute sProcData, object[] procValues)
            where T : ICisccDataObject, new()
        {
            DataSet _ds = new DataSet();

            using (SqlDataAdapter _adapter = GetStoredProcedureAdapter<T>(sProcData, procValues))
            {
                _adapter.Fill(_ds);
            }

            return _ds;
        }

        /// <remarks />
        public static DataSet RunStoredProcedure<T>(CisccSProcBaseAttribute sProcData, object[] procValues,
                                                        int startRecord, int maxRecords)
            where T : ICisccDataObject, new()
        {
            if (maxRecords == 0)
                return null;

            DataSet _ds = new DataSet();
            _ds.Tables.Add("SProcResult");

            using (SqlDataAdapter _adapter = GetStoredProcedureAdapter<T>(sProcData, procValues))
            {
                //_adapter.FillLoadOption = LoadOption.OverwriteChanges;
                _adapter.Fill(_ds, startRecord, maxRecords, "SProcResult");
            }

            return _ds;
        }

        /// <summary>
        /// Generic Stored procedure runner that support paging
        /// </summary>
        /// <typeparam name="T">Type of ICisccDataObject to return</typeparam>
        /// <typeparam name="Sp">Type of CisccSProcBaseAttribute Stored procedureto select</typeparam>
        /// <param name="obj">Object to Process against</param>
        public static void RunStoredProcedure<T, Sp>(ref T obj)
            where T : ICisccDataObject, new()
            where Sp : CisccSProcBaseAttribute
        {
            if (obj == null)
                obj = new T();

            object[] _params = GetStoredProcedureParams<T, Sp>(obj);
            DataSet _ds = new DataSet();
            using (SqlDataAdapter _adapter = GetStoredProcedureAdapter<T, Sp>(_params))
            {
                _adapter.Fill(_ds);
            }

            if (_ds != null &&
                _ds.Tables.Count > 0 &&
                _ds.Tables[0].Rows.Count > 0)
            {
                DataRow _dr = _ds.Tables[0].Rows[0];
                RowMerger(_dr, ref obj);
            }
        }

        #endregion

        /// <summary>
        /// Retrived an object array to match aginst the related 
        /// CisccSProcBaseAttribute.StoredProcedureKeys
        /// </summary>
        /// <typeparam name="T">Type of ICisccDataObject</typeparam>
        /// <typeparam name="Sp">Selected Stored procedure Attribute Type</typeparam>
        /// <param name="obj">object to scan</param>
        /// <returns>object[] of parameter values</returns>
        public static object[] GetStoredProcedureParams<T, Sp>(T obj)
            where T : ICisccDataObject, new()
            where Sp : CisccSProcBaseAttribute
        {
            Type _objType = obj.GetType();
            // Lookup Stored procedure related to this class type
            object[] _attributes = _objType.GetCustomAttributes(typeof(Sp), true);
            object[] _procParams = null;
            if (_attributes != null && _attributes.Length >= 1)
            {
                Sp _updateAttrib = _attributes[0] as Sp;
                _procParams = new object[_updateAttrib.StoredProcedureKeys.Length];

                if (obj == null)
                    return _procParams;

                for (int i = 0; i < _procParams.Length; i++)
                {
                    string _propName = _updateAttrib.StoredProcedureKeys[i] as string;

                    if (!string.IsNullOrEmpty(_propName))
                    {
                        PropertyInfo _propInfo = _objType.GetProperty(_propName);
                        GenericGetter propGetter = DynamicProperty.CreateGetMethod(_propInfo);

                        if (_propInfo == null)
                        {
                            Debug.WriteLine(string.Format(
                                "Property \"{0}\" is not found on Type \"{1}\"",
                                    _propName,
                                    _objType.FullName
                                ));
                            continue;
                        }
                        _procParams[i] = propGetter(obj);
                    }
                }
            }
            else
                throw new CisccAttributeException(string.Format(
                    "This \"{0}\" is not configured for \"{1}\"",
                    typeof(T), typeof(Sp)
                    ));

            return _procParams;
        }

        /// <summary>
        /// Retrives the attribute configuration from type ICisccDataObject
        /// </summary>
        /// <typeparam name="T">Type of ICisccDataObject</typeparam>
        /// <typeparam name="Sp">Selected Stored procedure Attribute Type</typeparam>
        /// <returns>Instance of CisccSProcBaseAttribute from ICisccDataObject</returns>
        public static Sp GetStoredProcedureAttribute<T, Sp>()
            where T : ICisccDataObject, new()
            where Sp : CisccSProcBaseAttribute
        {
            MemberInfo _mInfo = typeof(T);
            object[] _attributes = _mInfo.GetCustomAttributes(typeof(Sp), true);
            if (_attributes != null && _attributes.Length > 0)
                return _attributes[0] as Sp;
            else
                return default(Sp);
        }

        /// <summary>
        /// SqlDataAdapter to run stored procedure in CisccSProcBaseAttribute 
        /// related to ICisccDataObject.  With the paramater values from procValues
        /// </summary>
        /// <typeparam name="T">Type of ICisccDataObject</typeparam>
        /// <typeparam name="Sp">Selected Stored procedure Attribute Type</typeparam>
        /// <param name="procValues">object[] of parameter values</param>
        /// <returns>SqlDataAdapter</returns>
        public static SqlDataAdapter GetStoredProcedureAdapter<T, Sp>(object[] procValues)
            where T : ICisccDataObject, new()
            where Sp : CisccSProcBaseAttribute
        {
            Sp _attrib = GetStoredProcedureAttribute<T, Sp>();
            if (_attrib == null)
                throw new CisccAttributeException(string.Format(
                    "This \"{0}\" is not configured for \"{1}\"",
                    typeof(T), typeof(Sp)
                    ));

            return GetStoredProcedureAdapter<T>(_attrib, procValues);
        }

        /// <summary>
        /// SqlDataAdapter to run stored procedure in CisccSProcBaseAttribute 
        /// related to ICisccDataObject.  With the paramater values from procValues
        /// </summary>
        /// <typeparam name="T">Type of ICisccDataObject</typeparam>
        /// <param name="sProcData">Instance of CisccSProcBaseAttribute to process</param>
        /// <param name="procValues">object[] of parameter values</param>
        /// <returns>SqlDataAdapter</returns>
        public static SqlDataAdapter GetStoredProcedureAdapter<T>(CisccSProcBaseAttribute sProcData, object[] procValues)
            where T : ICisccDataObject, new()
        {
            if (sProcData == null)
                throw new CisccAttributeException();

            SqlConnection _connection = new SqlConnection(DataSqlSettings.CurrentConfig.ConnectionString);

            SqlCommand _cmd = new SqlCommand(
                sProcData.StoredProcedureName,
                _connection
                );
            _cmd.CommandType = CommandType.StoredProcedure;
            _cmd.CommandTimeout = DataSqlSettings.CurrentConfig.CommandTimeout;

            if (sProcData.StoredProcedureKeys != null && procValues != null)
            {
                for (int i = 0; i < sProcData.StoredProcedureKeys.Length; i++)
                {
                    _cmd.Parameters.Add(new SqlParameter(sProcData.StoredProcedureKeys[i], procValues[i]));
                }
            }

            MemberInfo _mInfo = typeof(T);
            object[] _attributes = _mInfo.GetCustomAttributes(typeof(CisccParamBaseAttribute), true);
            foreach (CisccParamBaseAttribute _paramAttrib in _attributes)
            {
                if ((_paramAttrib.UseWith & sProcData.SProcType) != sProcData.SProcType)
                    continue;

                SqlParameter _param = _paramAttrib.GetSqlParameter<T>();

                if (_param != null)
                    _cmd.Parameters.Add(_param);
            }

            return new SqlDataAdapter(_cmd);

        }

        #region Serializer/Deserializer

        /// <summary>
        /// DataRow deserializer for use with the CisccObjectFactory
        /// </summary>
        /// <typeparam name="T">Type of ICisccDataObject to deserializer for</typeparam>
        /// <param name="dataRow">Input datarow</param>
        /// <returns>new Object of Type ICisccDataObject from dataRow</returns>
        public static T RowDeserializer<T>(DataRow dataRow)
            where T : ICisccDataObject, new()
        {
            if (dataRow == null)
                throw new NullReferenceException();

            T _dataObj = new T();

            RowMerger(dataRow, ref _dataObj);
            return _dataObj;
        }

        /// <summary>
        /// DataRow deserializer for use with the CisccObjectFactory
        /// </summary>
        /// <typeparam name="T">Type of ICisccDataObject to deserializer for</typeparam>
        /// <param name="dataRow">Input datarow</param>
        /// <param name="mergeObject">Object of Type ICisccDataObject to fill from dataRow</param>
        public static void RowMerger<T>(DataRow dataRow, ref T mergeObject)
            where T : ICisccDataObject, new()
        {
            if (dataRow == null || mergeObject == null)
                throw new NullReferenceException();

            Type _localType = mergeObject.GetType();
            foreach (DataColumn _column in dataRow.Table.Columns)
            {
                PropertyInfo _prop = _localType.GetProperty(_column.ColumnName.Trim());
                GenericSetter propSetter = DynamicProperty.CreateSetMethod(_prop);
                GenericGetter propGetter = DynamicProperty.CreateGetMethod(_prop);
                if (_prop == null || propSetter == null)
                    continue;

                object _dataValue = dataRow[_column];
                object _currentValue = propGetter(mergeObject);

                if (_dataValue is DBNull || _dataValue == null)
                {
                    if (_currentValue == null)
                        continue;
                    else
                        propSetter(mergeObject, GenericParser.CreateInstance(_prop.PropertyType));
                }

                if (_dataValue.Equals(_currentValue))
                    continue;

                Type _propertyType = _prop.PropertyType;
                if (_propertyType.IsGenericType && _propertyType.Name == "Nullable`1")
                    _propertyType = _propertyType.GetGenericArguments()[0];

                if (_dataValue.GetType() == _propertyType)
                {
                    propSetter(mergeObject, _dataValue);
                }
                else
                {
                    object getValue;
                    if (GenericParser.TryParse(_propertyType, _dataValue.ToString(), out getValue))
                        propSetter(mergeObject, getValue);
                }
            }
        }

        //public static T XmlDeserializer<T>(string xmlData)
        //    where T : ICisccDataObject, new()
        //{
        //    if (string.IsNullOrEmpty(xmlData))
        //        return default(T);
        //    XmlSerializer _xSer = new XmlSerializer(typeof(T));
        //    using (MemoryStream _ms = new MemoryStream(ASCIIEncoding.UTF8.GetBytes(xmlData)))
        //    {
        //        return (T)_xSer.Deserialize(_ms);
        //    }
        //}

        //public static string XmlSerializer<T>(ICisccDataObject obj)
        //    where T : ICisccDataObject, new()
        //{
        //    if (obj == null)
        //        return null;

        //    XmlSerializer _xSer = new XmlSerializer(typeof(T));
        //    MemoryStream _ms = new MemoryStream();
        //    _xSer.Serialize(_ms, obj);
        //    byte[] _xmlBuffer = _ms.ToArray();
        //    if (_xmlBuffer == null)
        //        return null;
        //    return ASCIIEncoding.UTF8.GetString(_xmlBuffer);
        //}

        #endregion
    }
}
