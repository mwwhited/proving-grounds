using System;
using System.Collections.Generic;
using System.Text;

//CISCC.Common.RunTime.StringUtilities
namespace CISCC.Common.RunTime
{
    /// <remarks />
    public static class StringUtilities
    {
        /// <remarks />
        public static string ToShortenedString(string input, int maxLength)
        {
            if (string.IsNullOrEmpty(input))
                return input;

            if (maxLength < 3)
                return "...";

            if (input.Length > maxLength)
                return input.Substring(1, maxLength - 3) + "..."; 

            return input;
        }

        /// <remarks />
        public static string ToShortenedString(string input)
        {
            return ToShortenedString(input, 100);
        }

        /// <remarks />
        public static DateTime? GetDateFromString(string input)
        {
            if (string.IsNullOrEmpty(input))
                return null;

            DateTime result;
            if (DateTime.TryParse(input, out result))
                return result;
            else 
                return null;
        }
    }
}
