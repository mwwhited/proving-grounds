using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CISCC.Common.Data.Configuration
{
    /// <remarks />
    public class DataDateConfig : ConfigurationElement
    {
        /// <remarks />
        [ConfigurationProperty("workMonthFormatter", DefaultValue = "MM/yyyy")]
        public string WorkMonthFormatter
        {
            get
            {
                return this["workMonthFormatter"] as string;
            }
        }

        /// <remarks />
        [ConfigurationProperty("dateFormatter", DefaultValue = "MM/dd/yyyy")]
        public string DateFormatter
        {
            get
            {
                return this["dateFormatter"] as string;
            }
        }

        /// <remarks />
        [ConfigurationProperty("validDateRegex", DefaultValue = @"^((|0)[1-9]{1}|1[0-2]{1})\/((|0)[1-9]{1}|(1|2)[0-9]{1}|3[0-1])\/(|20|19)[0-9]{2}$")]
        public string ValidDateRegex
        {
            get
            {
                return this["validDateRegex"] as string;
            }
        }

        /// <remarks />
        public static DataDateConfig CurrentConfig { get { return DataConfiguration.CurrentConfig.DateConfig; } }
    }
}