using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

//CISCC.Common.Security.Configuration.SecurityConfiguration,CISCC.Common.Security
namespace CISCC.Common.Security.Configuration
{
    /// <remarks />
    public class SecurityConfiguration : ConfigurationSection
    {
        /// <remarks />
        [ConfigurationProperty("applicationName", IsRequired = true)]
        public string ApplicationName
        {
            get { return this["applicationName"] as string; }
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Application can not be null");

                this["applicationName"] = value;
            }
        }

        /// <remarks />
        [ConfigurationProperty("authenticationConfig", IsRequired = true)]
        public AuthenticationConfiguration AuthenticationConfig
        {
            get { return (this["authenticationConfig"] as AuthenticationConfiguration) ?? new AuthenticationConfiguration(); }
        }

        /// <remarks />
        [ConfigurationProperty("roleMap", IsRequired = true)]
        public RoleMapConfiguration RoleMap
        {
            get { return (this["roleMap"] as RoleMapConfiguration) ?? new RoleMapConfiguration(); }
        }

        /// <remarks />
        public static SecurityConfiguration CurrentConfig
        {
            get { return ConfigurationManager.GetSection("ciscSecurity") as SecurityConfiguration; }
        }
    }
}
