using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <remarks />
    public class CacheStats
    {
        /// <remarks />
        public CacheStats()
        {
        }

        private Type _relatedType = null;
        /// <remarks />
        public Type RelatedType
        {
            get
            {
                if (_relatedType.IsGenericType)
                    return _relatedType.GetGenericArguments()[0];
                return _relatedType;
            }
        }
        internal CacheStats(Type relatedType)
        {
            _relatedType = relatedType;
        }

        internal volatile int CacheHits = 0;
        internal volatile int CacheMisses = 0;
        internal volatile int CacheDirty = 0;
        internal volatile int CacheUpdates = 0;
        internal volatile int CacheErrors = 0;

        /// <remarks />
        public int Hits { get { return CacheHits; } }
        /// <remarks />
        public int Misses { get { return CacheMisses; } }
        /// <remarks />
        public int Dirty { get { return CacheDirty; } }
        /// <remarks />
        public int Updates { get { return CacheUpdates; } }
        /// <remarks />
        public int Errors { get { return CacheErrors; } }

        /// <remarks />
        public static CacheStats operator +(CacheStats left, CacheStats right)
        {
            left.CacheHits += right.CacheHits;
            left.CacheMisses += right.CacheMisses;
            left.CacheDirty += right.CacheDirty;
            left.CacheUpdates += right.CacheUpdates;
            left.CacheErrors += right.CacheErrors;
            return left;
        }

        internal static CacheStats Summerize(IEnumerable<CacheStats> stats)
        {
            CacheStats summary = new CacheStats();
            foreach (CacheStats stat in stats)
                summary += stat;

            return summary;
        }
    }
}
