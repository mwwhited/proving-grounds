using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CISCC.Common.Data.Configuration
{
    /// <remarks />
    public class DataLinkFormatters : ConfigurationElement
    {
        /// <remarks />
        [ConfigurationProperty("email", DefaultValue = "mailto:{0}")]
        public string Email
        {
            get
            {
                return this["email"] as string;
            }
        }

        /// <remarks />
        [ConfigurationProperty("employee", DefaultValue = "~/DetailEmployee.aspx?standardId={0}")]
        public string Employee
        {
            get
            {
                return this["employee"] as string;
            }
        }

        /// <remarks />
        [ConfigurationProperty("representative", DefaultValue = "~/DetailRepresentative.aspx?standardId={0}")]
        public string Representative
        {
            get
            {
                return this["representative"] as string;
            }
        }

        /// <remarks />
        [ConfigurationProperty("compliance", DefaultValue = "~/DetailCompliance.aspx?standardId={0}")]
        public string Compliance
        {
            get
            {
                return this["compliance"] as string;
            }
        }

        /// <remarks />
        public static DataLinkFormatters CurrentConfig { get { return DataConfiguration.CurrentConfig.LinkFormatters; } }
    }
}
