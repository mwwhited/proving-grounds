using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Enumeration of Stored procedure Types supported by CisccObjectFactory
    /// </summary>
    [Flags]
    public enum CisccSProcType
    {
        /// <summary>
        /// Create/Insert
        /// </summary>
        Create = 1,

        /// <summary>
        /// Read / Select
        /// </summary>
        Read = 2,

        /// <summary>
        /// Update
        /// </summary>
        Update = 4,

        /// <summary>
        /// Delete
        /// </summary>
        Delete = 8,

        /// <summary>
        /// All Standard Procedures
        /// </summary>
        CRUD = Create | Read | Update | Delete,

        /// <summary>
        /// Extended "Query"
        /// </summary>
        Query = 16,

        /// <summary>
        /// Extended "Item Count"
        /// </summary>
        ItemCount = 32,

        /// <summary>
        /// Extended "Cache Check"
        /// </summary>
        CacheCheck = 64
    }
}
