using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Diagnostics;
using System.ComponentModel;
using CISCC.Common.Security.Configuration;

namespace CISCC.Common.Security
{
    /// <summary>
    /// Global Security Values
    /// </summary>
    public class SecurityConstants
    {
        /// <summary>
        /// Session Key Name for user Profile
        /// </summary>
        public static string UserProfile
        {
            get { return AuthenticationConfiguration.CurrentConfig.UserProfile; }
        }

        /// <summary>
        /// Logout URL
        /// </summary>
        public static string LogoutUrl
        {
            get { return AuthenticationConfiguration.CurrentConfig.LogoutUrl; }
        }

#if DEBUG
        /// <summary>
        /// SSO Header Test Value
        /// </summary>
        public static string SsoHeaderTestId
        {
            get { return AuthenticationConfiguration.CurrentConfig.SsoHeaderTestId; }
        }
#endif

        /// <summary>
        /// SSO Header 
        /// </summary>
        public static string SsoHeader
        {
            get { return AuthenticationConfiguration.CurrentConfig.SsoHeader; }
        }

        /// <summary>
        /// Application Name 
        /// </summary>
        public static string ApplicationName
        {
            get { return SecurityConfiguration.CurrentConfig.ApplicationName; }
        }

        /// <summary>
        /// Read Only Role value in App.Config and Web.Config
        /// </summary>
        public static string RoleReadOnly
        {
            get { return RoleMapConfiguration.CurrentConfig.ReadOnly; }
        }

        /// <summary>
        /// Configuration Role value in App.Config and Web.Config
        /// </summary>
        public static string RoleMaintenance
        {
            get { return RoleMapConfiguration.CurrentConfig.Maintenance; }
        }

        /// <summary>
        /// Read/Write Role value in App.Config and Web.Config
        /// </summary>
        public static string RoleReadWrite
        {
            get { return RoleMapConfiguration.CurrentConfig.ReadWrite; }
        }

        /// <summary>
        /// Reporting Role value in App.Config and Web.Config
        /// </summary>
        public static string RolePublisher
        {
            get { return RoleMapConfiguration.CurrentConfig.Publisher; }
        }

        /// <summary>
        /// All Users Role value in App.Config and Web.Config
        /// </summary>
        public static string RoleAllUsers
        {
            get { return RoleMapConfiguration.CurrentConfig.AllUsers; }
        }
    }
}
