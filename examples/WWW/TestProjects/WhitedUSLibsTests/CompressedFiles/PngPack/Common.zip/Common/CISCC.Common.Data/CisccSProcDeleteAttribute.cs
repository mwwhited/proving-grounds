using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Attribute to Identity the Delete stored procedure for a class
    /// </summary>
    public class CisccSProcDeleteAttribute : CisccSProcBaseAttribute
    {
        /// <summary>
        /// Constructor for CisccSProcDeleteAttribute
        /// </summary>
        /// <param name="storedProcedureName">Name of Stored procedure</param>
        /// <param name="storedProcedureKeys">Key Names for parameters of stored procedure</param>
        public CisccSProcDeleteAttribute(string storedProcedureName, string[] storedProcedureKeys)
            : base (storedProcedureName, storedProcedureKeys, CisccSProcType.Delete)
        {
        }
    }
}
