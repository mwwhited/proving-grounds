using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Security
{
    /// <summary>
    /// Enumeration of RoleTypes allowed for use with CisccPrincipalUser
    /// </summary>
    [Flags]
    public enum RoleTypes
    {
        /// <summary>
        /// ReadOnly access
        /// </summary>
        ReadOnly = 1,

        /// <summary>
        /// Read and Write access / Data Entry
        /// </summary>
        ReadWrite = 2,

        /// <summary>
        /// Publisher access
        /// </summary>
        Publisher = 4,

        /// <summary>
        /// Application configuration and maintenance
        /// </summary>
        Maintenance = 8,

        /// <summary>
        /// Full Rights Allowed
        /// </summary>
        FullAccess = -1
    }
}
