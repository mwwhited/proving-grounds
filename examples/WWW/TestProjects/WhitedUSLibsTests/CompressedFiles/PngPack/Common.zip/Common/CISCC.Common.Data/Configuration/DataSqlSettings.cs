using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CISCC.Common.Data.Configuration
{
    /// <remarks />
    public class DataSqlSettings : ConfigurationElement
    {
        /// <remarks />
        [ConfigurationProperty("commandTimeout", DefaultValue = (int)100)]
        public int CommandTimeout
        {
            get
            {
                return (int)this["commandTimeout"];
            }
        }

        /// <remarks />
        [ConfigurationProperty("connectionString", IsRequired = true)]
        public string ConnectionString
        {
            get
            {
                return this["connectionString"] as string;
            }
        }

        /// <remarks />
        public static DataSqlSettings CurrentConfig { get { return DataConfiguration.CurrentConfig.SqlSettings; } }
    }
}
