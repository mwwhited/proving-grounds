using System;
using System.Collections.Generic;
using System.Text;

namespace CISCC.Common.Data
{
    /// <summary>
    /// Use this interface to flag data classes that are Cacheable
    /// </summary>
    public interface ICisccCacheable : ICisccDataObject
    {
        /// <summary>
        /// Date/Time Stamp the Object was last updated in the database
        /// </summary>
        DateTime ModifiedDateTime { get;set;}

        /// <summary>
        /// Date/Time Stamp that Object was created in the Database
        /// </summary>
        DateTime CreatedDateTime { get;set;}
    }
}
