<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:DTS="www.microsoft.com/SqlServer/Dts"
  >
  <xsl:template match="/">
    <table border="1">
      <tr>
        <th>File</th>
        <th>Column</th>
        <th>Width</th>
        <th>Delimiter</th>
      </tr>
      <xsl:for-each select="/DTS:Executable/DTS:ConnectionManager/DTS:Property[@DTS:Name='CreationName']/..">
        <xsl:for-each select="DTS:ObjectData/DTS:ConnectionManager/DTS:FlatFileColumn">
          <tr>
            <td>
              <xsl:value-of select="../../../DTS:PropertyExpression"/>
            </td>
            <td>
              <xsl:value-of select="DTS:Property[@DTS:Name='ObjectName']"/>
            </td>
            <td>
              <xsl:value-of select="DTS:Property[@DTS:Name='ColumnWidth']"/>
            </td>
            <td>
              <xsl:value-of select="DTS:Property[@DTS:Name='ColumnDelimiter']"/>
            </td>
          </tr>
        </xsl:for-each>
      </xsl:for-each>
    </table>

  </xsl:template>

</xsl:stylesheet>
